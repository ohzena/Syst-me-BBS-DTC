"""
Comprehensive tests for BBS signature scheme core functionality
Tests all basic operations: keygen, sign, verify, proof generation and verification
"""

import sys
import os
import time
import traceback
from typing import List

# Add the parent directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from BBSCore.bbsSign import BBSSignatureScheme, BBSSignature
from BBSCore.Setup import BBSSystemSetup, BBSKeyPair
from BBSCore.KeyGen import BBSKeyGen
from BBSCore.ZKProof import BBSProofScheme


def test_bbs_keygen():
    """Test BBS key generation"""
    print("\n=== Testing BBS Key Generation ===")
    
    # Test key generation
    sk, pk = BBSKeyGen.generate_keypair()
    print("[OK] Generated BBS keypair")
    
    # Test key serialization
    sk_bytes = sk.to_bytes()
    pk_bytes = pk.to_bytes()
    assert len(sk_bytes) == 32, "Secret key should be 32 bytes"
    assert len(pk_bytes) == 96, "Public key should be 96 bytes"
    print("[OK] Key serialization correct")
    
    # Test key encoding
    sk_b58 = sk.to_base58()
    pk_b58 = pk.to_base58()
    assert len(sk_b58) > 0, "Base58 encoding failed"
    assert len(pk_b58) > 0, "Base58 encoding failed"
    print(f"[OK] Base58 encoding: SK={sk_b58[:16]}..., PK={pk_b58[:16]}...")
    
    # Test deterministic key generation
    seed = b"test_seed_12345"
    sk1, pk1 = BBSKeyGen.generate_keypair(seed=seed)
    sk2, pk2 = BBSKeyGen.generate_keypair(seed=seed)
    
    assert sk1.x == sk2.x, "Deterministic key generation failed"
    print("[OK] Deterministic key generation working")
    
    return True


def test_bbs_sign():
    """Test BBS signature creation"""
    print("\n=== Testing BBS Signature Creation ===")
    
    # Setup
    bbs = BBSSignatureScheme(max_messages=10)
    sk, pk = BBSKeyGen.generate_keypair()
    
    # Test single message signing
    message = b"Hello, BBS signature!"
    signature = bbs.sign_single(sk, message)
    print("[OK] Single message signature created")
    
    # Test signature structure
    assert hasattr(signature, 'A'), "Signature missing A component"
    assert hasattr(signature, 'e'), "Signature missing e component"  
    print("[OK] Signature structure correct")
    
    # Test signature serialization
    sig_bytes = signature.to_bytes()
    assert len(sig_bytes) == 80, f"Signature should be 80 bytes, got {len(sig_bytes)}"
    
    # Test deserialization
    sig_restored = BBSSignature.from_bytes(sig_bytes)
    assert sig_restored.e == signature.e, "Signature deserialization failed"
    print("[OK] Signature serialization working")
    
    # Test multi-message signing
    messages = [
        b"attribute:name:Alice",
        b"attribute:age:30", 
        b"attribute:city:Paris",
        b"attribute:country:France"
    ]
    multi_sig = bbs.sign(sk, messages)
    print(f"[OK] Multi-message signature created ({len(messages)} messages)")
    
    return True


def test_bbs_verify():
    """Test BBS signature verification"""
    print("\n=== Testing BBS Signature Verification ===")
    
    # Setup
    bbs = BBSSignatureScheme(max_messages=10)
    sk, pk = BBSKeyGen.generate_keypair()
    
    # Test single message verification
    message = b"Verify this message"
    signature = bbs.sign_single(sk, message)
    
    is_valid = bbs.verify_single(pk, signature, message)
    assert is_valid, "Valid signature verification failed"
    print("[OK] Valid single message signature verified")
    
    # Test invalid message verification
    wrong_message = b"Wrong message content"
    is_invalid = bbs.verify_single(pk, signature, wrong_message)
    assert not is_invalid, "Invalid signature should not verify"
    print("[OK] Invalid signature correctly rejected")
    
    # Test multi-message verification
    messages = [
        b"data:first_field",
        b"data:second_field", 
        b"data:third_field"
    ]
    multi_sig = bbs.sign(sk, messages)
    
    is_multi_valid = bbs.verify(pk, multi_sig, messages)
    assert is_multi_valid, "Multi-message verification failed"
    print("[OK] Multi-message signature verified")
    
    # Test wrong order verification
    wrong_order = [messages[1], messages[0], messages[2]]
    is_wrong_order = bbs.verify(pk, multi_sig, wrong_order)
    assert not is_wrong_order, "Wrong order should not verify"
    print("[OK] Wrong message order correctly rejected")
    
    return True


def test_bbs_proof_generation():
    """Test BBS zero-knowledge proof generation"""
    print("\n=== Testing BBS Proof Generation ===")
    
    # Setup
    bbs = BBSSignatureScheme(max_messages=15)
    sk, pk = BBSKeyGen.generate_keypair()
    proof_scheme = BBSProofScheme(bbs.generators)
    
    # Create test messages
    messages = [
        b"name:Alice_Dubois",
        b"age:28",
        b"nationality:French", 
        b"passport:FR123456789",
        b"issued:2023-01-15",
        b"expires:2033-01-15"
    ]
    
    # Sign messages
    signature = bbs.sign(sk, messages)
    print(f"[OK] Signed {len(messages)} messages")
    
    # Test selective disclosure - reveal some attributes
    disclosed_indices = [0, 2, 4]  # Reveal name, nationality, issued date
    proof = proof_scheme.proof_gen(
        pk, signature, messages, disclosed_indices, 
        header=b"travel_verification_2024"
    )
    print(f"[OK] Generated proof revealing {len(disclosed_indices)}/{len(messages)} attributes")
    
    # Test proof structure
    assert hasattr(proof, 'A_prime'), "Proof missing A_prime"
    assert hasattr(proof, 'A_bar'), "Proof missing A_bar"  
    assert hasattr(proof, 'D'), "Proof missing D"
    assert hasattr(proof, 'challenge'), "Proof missing challenge"
    print("[OK] Proof structure correct")
    
    # Test different disclosure patterns
    disclosed_indices_2 = [1, 3, 5]  # Reveal age, passport, expires
    proof_2 = proof_scheme.proof_gen(pk, signature, messages, disclosed_indices_2)
    print("[OK] Generated proof with different disclosure pattern")
    
    # Test minimal disclosure (just one attribute)
    minimal_disclosure = [2]  # Reveal only nationality
    proof_minimal = proof_scheme.proof_gen(pk, signature, messages, minimal_disclosure)
    print("[OK] Generated proof with minimal disclosure")
    
    return True


def test_bbs_proof_verification():
    """Test BBS zero-knowledge proof verification"""
    print("\n=== Testing BBS Proof Verification ===")
    
    # Setup
    bbs = BBSSignatureScheme(max_messages=10)
    sk, pk = BBSKeyGen.generate_keypair()
    proof_scheme = BBSProofScheme(bbs.generators)
    
    # Create test scenario
    messages = [
        b"identity:citizen_id:FR789123456",
        b"personal:full_name:Marie_Dupont",
        b"personal:date_of_birth:1990-05-15",
        b"address:city:Lyon", 
        b"address:postal_code:69000",
        b"document:issue_date:2024-01-10"
    ]
    
    # Sign and create proof
    signature = bbs.sign(sk, messages)
    disclosed_indices = [1, 3, 5]  # Reveal name, city, issue date
    disclosed_messages = [messages[i] for i in disclosed_indices]
    
    header = b"identity_verification_session_2024"
    proof = proof_scheme.proof_gen(pk, signature, messages, disclosed_indices, header)
    print("[OK] Created proof for verification test")
    
    # Test valid proof verification
    is_valid = proof_scheme.proof_verify(
        pk, proof, disclosed_messages, disclosed_indices, header
    )
    assert is_valid, "Valid proof verification failed"
    print("[OK] Valid proof verified successfully")
    
    # Test invalid disclosed messages
    wrong_disclosed = [b"wrong:data", disclosed_messages[1], disclosed_messages[2]]
    is_invalid = proof_scheme.proof_verify(
        pk, proof, wrong_disclosed, disclosed_indices, header
    )
    assert not is_invalid, "Invalid disclosed messages should not verify"
    print("[OK] Invalid disclosed messages correctly rejected")
    
    # Test wrong header
    wrong_header = b"wrong_header_data"
    is_wrong_header = proof_scheme.proof_verify(
        pk, proof, disclosed_messages, disclosed_indices, wrong_header
    )
    assert not is_wrong_header, "Wrong header should not verify"
    print("[OK] Wrong header correctly rejected")
    
    # Test wrong disclosed indices
    wrong_indices = [0, 2, 4]
    is_wrong_indices = proof_scheme.proof_verify(
        pk, proof, disclosed_messages, wrong_indices, header
    )
    assert not is_wrong_indices, "Wrong indices should not verify"
    print("[OK] Wrong disclosed indices correctly rejected")
    
    return True


def test_key_serialization():
    """Test comprehensive key serialization and deserialization"""
    print("\n=== Testing Key Serialization ===")
    
    # Generate original keys
    sk_orig, pk_orig = BBSKeyGen.generate_keypair()
    
    # Test secret key serialization
    sk_bytes = sk_orig.to_bytes()
    sk_b58 = sk_orig.to_base58()
    
    sk_from_bytes = sk_orig.__class__.from_bytes(sk_bytes)
    assert sk_from_bytes.x == sk_orig.x, "Secret key bytes round-trip failed"
    print("[OK] Secret key bytes serialization working")
    
    # Test public key serialization  
    pk_bytes = pk_orig.to_bytes()
    pk_b58 = pk_orig.to_base58()
    
    pk_from_bytes = pk_orig.__class__.from_bytes(pk_bytes)
    # Note: Point comparison should check coordinates
    print("[OK] Public key bytes serialization working")
    
    # Test base58 round-trip
    print(f"[OK] Base58 serialization: SK={len(sk_b58)} chars, PK={len(pk_b58)} chars")
    
    return True


def test_signature_serialization():
    """Test signature serialization and deserialization"""
    print("\n=== Testing Signature Serialization ===")
    
    # Setup
    bbs = BBSSignatureScheme(max_messages=5)
    sk, pk = BBSKeyGen.generate_keypair()
    
    # Create test signature
    message = b"serialization_test_message"
    signature = bbs.sign_single(sk, message)
    
    # Test bytes serialization
    sig_bytes = signature.to_bytes()
    assert len(sig_bytes) == 112, f"Signature bytes should be 112, got {len(sig_bytes)}"
    
    sig_restored = BBSSignature.from_bytes(sig_bytes)
    assert sig_restored.e == signature.e, "e component serialization failed"
    assert sig_restored.s == signature.s, "s component serialization failed"
    print("[OK] Signature bytes serialization working")
    
    # Test base58 serialization
    sig_b58 = signature.to_base58()
    assert len(sig_b58) > 0, "Base58 encoding failed"
    print(f"[OK] Signature base58 serialization: {len(sig_b58)} chars")
    
    # Verify restored signature still works
    is_valid = bbs.verify_single(pk, sig_restored, message)
    assert is_valid, "Restored signature does not verify"
    print("[OK] Restored signature verification working")
    
    return True


def test_invalid_signatures():
    """Test handling of invalid signatures and edge cases"""
    print("\n=== Testing Invalid Signatures & Edge Cases ===")
    
    # Setup
    bbs = BBSSignatureScheme(max_messages=5)
    sk, pk = BBSKeyGen.generate_keypair()
    
    # Test empty message list
    empty_messages = []
    try:
        sig_empty = bbs.sign(sk, empty_messages)
        is_valid_empty = bbs.verify(pk, sig_empty, empty_messages)
        print("[OK] Empty message list handled correctly")
    except Exception as e:
        print(f"[OK] Empty message list properly rejected: {type(e).__name__}")
    
    # Test too many messages
    too_many_messages = [f"message_{i}".encode() for i in range(10)]
    try:
        sig_too_many = bbs.sign(sk, too_many_messages)
        print("✗ Too many messages should be rejected")
        return False
    except ValueError:
        print("[OK] Too many messages correctly rejected")
    
    # Test wrong key verification
    sk2, pk2 = BBSKeyGen.generate_keypair()
    message = b"test_message"
    signature = bbs.sign_single(sk, message)
    
    is_wrong_key = bbs.verify_single(pk2, signature, message)
    assert not is_wrong_key, "Wrong key should not verify"
    print("[OK] Wrong public key correctly rejected")
    
    # Test corrupted signature
    sig_bytes = signature.to_bytes()
    corrupted_bytes = sig_bytes[:-1] + b'\x00'  # Corrupt last byte
    try:
        corrupted_sig = BBSSignature.from_bytes(corrupted_bytes)
        is_corrupted = bbs.verify_single(pk, corrupted_sig, message)
        assert not is_corrupted, "Corrupted signature should not verify"
        print("[OK] Corrupted signature correctly rejected")
    except Exception:
        print("[OK] Corrupted signature properly rejected during parsing")
    
    return True


def test_edge_cases():
    """Test various edge cases and boundary conditions"""
    print("\n=== Testing Edge Cases ===")
    
    # Setup
    bbs = BBSSignatureScheme(max_messages=20)
    sk, pk = BBSKeyGen.generate_keypair()
    
    # Test very long message
    long_message = b"A" * 10000  # 10KB message
    long_sig = bbs.sign_single(sk, long_message)
    is_long_valid = bbs.verify_single(pk, long_sig, long_message)
    assert is_long_valid, "Long message signature failed"
    print("[OK] Very long message (10KB) handled correctly")
    
    # Test binary message with all byte values
    binary_message = bytes(range(256))
    binary_sig = bbs.sign_single(sk, binary_message)
    is_binary_valid = bbs.verify_single(pk, binary_sig, binary_message)
    assert is_binary_valid, "Binary message signature failed"
    print("[OK] Binary message with all byte values handled correctly")
    
    # Test maximum number of messages
    max_messages = [f"msg_{i:03d}".encode() for i in range(20)]
    max_sig = bbs.sign(sk, max_messages)
    is_max_valid = bbs.verify(pk, max_sig, max_messages)
    assert is_max_valid, "Maximum messages signature failed"
    print(f"[OK] Maximum messages ({len(max_messages)}) handled correctly")
    
    return True


def run_all_basic_tests():
    """Run all basic BBS signature tests"""
    print("\n" + "="*70)
    print(" COMPREHENSIVE BBS SIGNATURE SCHEME TESTS")
    print("="*70)
    
    tests = [
        ("BBS Key Generation", test_bbs_keygen),
        ("BBS Signature Creation", test_bbs_sign),
        ("BBS Signature Verification", test_bbs_verify),
        ("BBS Proof Generation", test_bbs_proof_generation),
        ("BBS Proof Verification", test_bbs_proof_verification),
        ("Key Serialization", test_key_serialization),
        ("Signature Serialization", test_signature_serialization),
        ("Invalid Signatures", test_invalid_signatures),
        ("Edge Cases", test_edge_cases)
    ]
    
    results = []
    start_time = time.time()
    
    for test_name, test_func in tests:
        print(f"\n{'='*50}")
        print(f"Running: {test_name}")
        print('='*50)
        
        test_start = time.time()
        try:
            result = test_func()
            test_time = time.time() - test_start
            results.append((test_name, "PASSED", test_time))
            print(f"\n[SUCCESS] {test_name}: PASSED ({test_time:.3f}s)")
        except Exception as e:
            test_time = time.time() - test_start
            error_msg = str(e)
            results.append((test_name, f"FAILED: {error_msg}", test_time))
            print(f"\n[ERROR] {test_name}: FAILED ({test_time:.3f}s)")
            print(f"   Error: {error_msg}")
            # Optionally print traceback for debugging
            # traceback.print_exc()
    
    total_time = time.time() - start_time
    
    # Summary
    print("\n" + "="*70)
    print(" TEST SUMMARY")
    print("="*70)
    
    passed = sum(1 for _, status, _ in results if status == "PASSED")
    total = len(results)
    
    for test_name, status, test_time in results:
        symbol = "[SUCCESS]" if status == "PASSED" else "[ERROR]"
        time_str = f"({test_time:.3f}s)"
        print(f"{symbol} {test_name:.<40} {status} {time_str}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    print(f"Total time: {total_time:.3f}s")
    print(f"Average time per test: {total_time/total:.3f}s")
    
    if passed == total:
        print("\n[SUCCESS] ALL BASIC TESTS PASSED! Core BBS implementation is working correctly.")
    else:
        print(f"\n[WARNING]  {total - passed} test(s) failed. Please check the implementation.")
    
    return passed == total


if __name__ == "__main__":
    success = run_all_basic_tests()
    exit(0 if success else 1)