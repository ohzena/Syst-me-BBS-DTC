# Test/test_core_tex_compliance.py
"""
Test suite to verify Core.tex specification compliance
Tests the refactored BBS implementation against the specification
"""

import sys
import os
import time
import hashlib
from typing import List, Tuple

# Add parent directory to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from BBSCore.Setup import BBSSecretKey, BBSPublicKey, BBSGenerators, P1, P2, CURVE_ORDER
from BBSCore.KeyGen import BBSKeyGen
from BBSCore.bbsSign import BBSSignature, BBSSignatureScheme
from BBSCore.ZKProof import BBSProof, BBSProofScheme


def test_signature_structure():
    """Test that signature follows Core.tex structure (A, e) only"""
    print("\n=== Testing Signature Structure (Core.tex Compliance) ===")
    
    # Generate keys
    sk, pk = BBSKeyGen.generate_keypair()
    
    # Create scheme and sign
    bbs = BBSSignatureScheme(max_messages=5)
    messages = [b"msg1", b"msg2", b"msg3"]
    signature = bbs.sign(sk, messages)
    
    # Check signature structure
    assert hasattr(signature, 'A'), "Signature missing A component"
    assert hasattr(signature, 'e'), "Signature missing e component"
    assert not hasattr(signature, 's'), "Signature should NOT have s component "
    
    # Check serialization size
    sig_bytes = signature.to_bytes()
    assert len(sig_bytes) == 80, f"Signature should be 80 bytes, got {len(sig_bytes)}"
    
    print(f"  [OK] Signature structure: (A, e)")
    print(f"  [OK] Signature size: 80 bytes")
    
    # Test deserialization
    sig_restored = BBSSignature.from_bytes(sig_bytes)
    assert sig_restored.e == signature.e, "Deserialization failed"
    
    print(f"  [OK] Serialization/deserialization working")
    
    return True


def test_core_sign_verify():
    """Test CoreSign and CoreVerify operations"""
    print("\n=== Testing CoreSign and CoreVerify  ===")
    
    # Generate keys
    sk, pk = BBSKeyGen.generate_keypair()
    
    # Test with different message counts
    test_cases = [
        ([], b"empty"),                    # No messages
        ([b"single"], b"header1"),         # Single message
        ([b"msg1", b"msg2", b"msg3"], b"header2"),  # Multiple messages
    ]
    
    bbs = BBSSignatureScheme(max_messages=10)
    
    for messages, header in test_cases:
        print(f"\n  Testing with {len(messages)} messages...")
        
        # Sign
        signature = bbs.core_sign(sk, pk, header, messages)
        
        # Verify
        is_valid = bbs.core_verify(pk, signature, header, messages)
        assert is_valid, f"Verification failed for {len(messages)} messages"
        print(f"    [OK] Sign/Verify successful")
        
        # Test with wrong message
        if messages:
            wrong_messages = messages[:-1] + [b"wrong"]
            is_invalid = bbs.core_verify(pk, signature, header, wrong_messages)
            assert not is_invalid, "Should fail with wrong message"
            print(f"    [OK] Correctly rejects invalid message")
    
    return True


def test_generators_creation():
    """Test generator creation follows spec"""
    print("\n=== Testing Generator Creation  ===")
    
    # Create generators
    generators = BBSGenerators.create_generators(count=5, api_id=b"test")
    
    # Should have L+1 generators: Q_1, H_1, ..., H_L
    assert len(generators) == 6, f"Should have 6 generators (Q_1 + 5 H_i), got {len(generators)}"
    
    print(f"  [OK] Created {len(generators)} generators")
    
    # Verify all are valid points
    from ec import JacobianPoint
    for i, gen in enumerate(generators):
        assert isinstance(gen, JacobianPoint), f"Generator {i} is not a JacobianPoint"
        assert not gen.infinity, f"Generator {i} is point at infinity"
    
    print(f"  [OK] All generators are valid G1 points")
    
    # Test deterministic generation
    generators2 = BBSGenerators.create_generators(count=5, api_id=b"test")
    for i, (g1, g2) in enumerate(zip(generators, generators2)):
        assert g1.x == g2.x and g1.y == g2.y, f"Generator {i} not deterministic"
    
    print(f"  [OK] Generator creation is deterministic")
    
    return True


def test_proof_structure():
    """Test that proof follows Core.tex structure"""
    print("\n=== Testing Proof Structure  ===")
    
    # Setup
    bbs_zk = BBSProofScheme(max_messages=10)
    sk, pk = BBSKeyGen.generate_keypair()
    
    # Create signature
    messages = [b"attr1", b"attr2", b"attr3", b"attr4"]
    header = b"context"
    signature = bbs_zk.sign(sk, messages, header)
    
    # Generate proof
    disclosed_indexes = [0, 2]
    proof = bbs_zk.generate_proof(
        pk, signature, header, messages,
        disclosed_indexes, b"presentation"
    )
    
    # Check proof structure per Core.tex
    assert hasattr(proof, 'Abar'), "Proof missing Abar"
    assert hasattr(proof, 'Bbar'), "Proof missing Bbar"
    assert hasattr(proof, 'D'), "Proof missing D"
    assert hasattr(proof, 'e_hat'), "Proof missing e^"
    assert hasattr(proof, 'r1_hat'), "Proof missing r1^"
    assert hasattr(proof, 'r3_hat'), "Proof missing r3^"
    assert hasattr(proof, 'commitments'), "Proof missing commitments"
    assert hasattr(proof, 'cp'), "Proof missing challenge"
    
    print(f"  [OK] Proof has all required components")
    
    # Check commitments count
    U = len(messages) - len(disclosed_indexes)  # Undisclosed count
    assert len(proof.commitments) == U, f"Should have {U} commitments, got {len(proof.commitments)}"
    
    print(f"  [OK] Correct number of commitments: {U}")
    
    # Test serialization
    proof_bytes = proof.to_bytes()
    proof_restored = BBSProof.from_bytes(proof_bytes)
    assert proof_restored.cp == proof.cp, "Proof deserialization failed"
    
    print(f"  [OK] Proof serialization working")
    
    return True


def test_proof_generation_verification():
    """Test complete proof generation and verification flow"""
    print("\n=== Testing Proof Generation/Verification  ===")
    
    # Setup
    bbs_zk = BBSProofScheme(max_messages=10)
    sk, pk = BBSKeyGen.generate_keypair()
    
    # Test cases with different disclosure patterns
    test_cases = [
        {
            'messages': [b"name:Alice", b"age:30", b"city:Paris", b"id:12345"],
            'disclosed': [0, 2],  # Reveal name and city
            'header': b"credential",
            'ph': b"verifier_nonce"
        },
        {
            'messages': [b"attr1", b"attr2"],
            'disclosed': [1],  # Reveal only second
            'header': b"test",
            'ph': b""
        },
        {
            'messages': [b"secret1", b"secret2", b"secret3"],
            'disclosed': [],  # Reveal nothing
            'header': b"",
            'ph': b"challenge"
        }
    ]
    
    for i, test in enumerate(test_cases):
        print(f"\n  Test case {i+1}:")
        print(f"    Messages: {len(test['messages'])}")
        print(f"    Disclosed: {test['disclosed']}")
        
        # Sign
        signature = bbs_zk.sign(sk, test['messages'], test['header'])
        
        # Generate proof
        proof = bbs_zk.generate_proof(
            pk, signature, test['header'],
            test['messages'], test['disclosed'], test['ph']
        )
        
        # Verify proof
        disclosed_msgs = [test['messages'][j] for j in test['disclosed']]
        is_valid = bbs_zk.verify_proof(
            pk, proof, test['header'],
            disclosed_msgs, test['disclosed'], test['ph']
        )
        
        assert is_valid, f"Proof verification failed for test case {i+1}"
        print(f"    [OK] Proof verified successfully")
        
        # Test with wrong disclosed message
        if disclosed_msgs:
            wrong_msgs = disclosed_msgs[:-1] + [b"wrong"]
            is_invalid = bbs_zk.verify_proof(
                pk, proof, test['header'],
                wrong_msgs, test['disclosed'], test['ph']
            )
            assert not is_invalid, "Should fail with wrong disclosed message"
            print(f"    [OK] Correctly rejects invalid disclosure")
    
    return True


def test_pairing_equation():
    """Test that pairing equation matches Core.tex"""
    print("\n=== Testing Pairing Equation  ===")
    
    from pairing import ate_pairing
    from fields import Fq12
    from ec import JacobianPoint, scalar_mult_jacobian, default_ec
    
    # Generate test keys
    sk, pk = BBSKeyGen.generate_keypair()
    
    # Create and verify a signature
    bbs = BBSSignatureScheme(max_messages=5)
    messages = [b"test1", b"test2"]
    signature = bbs.sign(sk, messages)
    
    # Manual verification using Core.tex equation:
    # e(A, W) * e(A * e - B, P2) = Identity_GT
    
    # This is tested internally in core_verify
    is_valid = bbs.verify(pk, signature, messages)
    assert is_valid, "Pairing equation verification failed"
    
    print(f"  [OK] Pairing equation matches Core.tex specification")
    
    return True


def run_all_core_tex_tests():
    """Run all Core.tex compliance tests"""
    print("\n" + "="*70)
    print(" CORE.TEX SPECIFICATION COMPLIANCE TESTS")
    print("="*70)
    
    tests = [
        ("Signature Structure", test_signature_structure),
        ("Core Sign/Verify", test_core_sign_verify),
        ("Generator Creation", test_generators_creation),
        ("Proof Structure", test_proof_structure),
        ("Proof Gen/Verify", test_proof_generation_verification),
        ("Pairing Equation", test_pairing_equation),
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print(f"\nRunning: {test_name}")
        print("-" * 50)
        
        try:
            result = test_func()
            results.append((test_name, "PASSED"))
            print(f"\n[PASS] {test_name}")
        except Exception as e:
            results.append((test_name, f"FAILED: {e}"))
            print(f"\n[FAIL] {test_name}: {e}")
    
    # Summary
    print("\n" + "="*70)
    print(" TEST SUMMARY")
    print("="*70)
    
    passed = sum(1 for _, status in results if status == "PASSED")
    total = len(results)
    
    for test_name, status in results:
        symbol = "[OK]" if status == "PASSED" else "[FAIL]"
        print(f"{symbol} {test_name:.<50} {status}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n[SUCCESS] All Core.tex compliance tests passed!")
        print("Your implementation correctly follows the specification.")
    else:
        print(f"\n[WARNING] {total - passed} test(s) failed.")
        print("Please review the implementation against Core.tex.")
    
    return passed == total


if __name__ == "__main__":
    success = run_all_core_tex_tests()
    exit(0 if success else 1)