"""
Integration tests for complete BBS + DTC workflows
Tests end-to-end scenarios with multiple actors and documents
"""

import sys
import os
import time
from typing import List, Dict, Any

# Add the parent directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from BBSCore.KeyGen import BBSKeyGen
from DTC.dtc import DTCCredential, DocumentType
from DTC.DTCIssuer import DTCIssuer
from DTC.DTCHolder import DTCHolder
from DTC.DTCVerifier import DTCVerifier


def test_complete_travel_workflow():
    """Test complete international travel workflow with multiple documents"""
    print("\n=== Testing Complete Travel Workflow ===")
    print("Scenario: Alice travels from France → UK with multiple documents")
    
    # === SETUP MULTIPLE ISSUERS ===
    print("\n--- Setup Phase: Multiple Issuers ---")
    
    french_govt = DTCIssuer("French Government")
    health_authority = DTCIssuer("French Health Authority")
    print("[OK] Created 2 issuers: French Government, Health Authority")
    
    # === SETUP HOLDER ===
    alice = DTCHolder("Alice Dubois")
    print("[OK] Created holder: Alice Dubois")
    
    # === SETUP VERIFIERS ===
    uk_border = DTCVerifier("UK Border Control")
    uk_border.add_trusted_issuer("French Government", french_govt.public_key)
    uk_border.add_trusted_issuer("French Health Authority", health_authority.public_key)
    
    airline = DTCVerifier("Air France")
    airline.add_trusted_issuer("French Government", french_govt.public_key)
    
    print("[OK] Created 2 verifiers with appropriate trust relationships")
    
    # === CREDENTIAL ISSUANCE PHASE ===
    print("\n--- Credential Issuance Phase ---")
    
    # 1. French passport
    passport_attrs = {
        'full_name': 'Alice Marie Dubois',
        'date_of_birth': '1995-03-15',
        'nationality': 'French',
        'passport_number': 'FR789456123',
        'issuing_authority': 'République Française',
        'issue_date': '2024-01-15',
        'expiry_date': '2034-01-15',
        'place_of_birth': 'Lyon, France'
    }
    
    passport = french_govt.issue_credential(
        document_type=DocumentType.PASSPORT,
        attributes=passport_attrs,
        holder_id="alice@example.fr"
    )
    alice.store_credential("french_passport", passport)
    print("[OK] French passport issued and stored")
    
    # 2. Health certificate
    health_attrs = {
        'vaccine_name': 'COVID-19 mRNA',
        'manufacturer': 'Pfizer-BioNTech',
        'batch_number': 'EW0150',
        'vaccination_date': '2023-10-15',
        'administering_authority': 'Lyon Health Center',
        'doses_received': '3',
        'next_dose_due': 'As recommended'
    }
    
    health_cert = health_authority.issue_credential(
        document_type=DocumentType.VACCINATION,
        attributes=health_attrs,
        holder_id="alice@example.fr"
    )
    alice.store_credential("health_certificate", health_cert)
    print("[OK] Health certificate issued and stored")
    
    print(f"[OK] Alice now has {len(alice.credentials)} credentials in her wallet")
    
    # === TRAVEL JOURNEY ===
    print("\n--- Travel Journey ---")
    
    # STEP 1: France → UK (Border Control)
    print("\n1. France → UK Border Control")
    
    passport_proof_uk, passport_disclosed_uk, passport_indices_uk = alice.create_presentation(
        credential_id="french_passport",
        issuer_pk=french_govt.public_key,
        attributes_to_reveal=['full_name', 'nationality', 'expiry_date'],
        presentation_header=b"uk_border_entry_2024"
    )
    
    health_proof_uk, health_disclosed_uk, health_indices_uk = alice.create_presentation(
        credential_id="health_certificate", 
        issuer_pk=health_authority.public_key,
        attributes_to_reveal=['vaccine_name', 'vaccination_date', 'doses_received'],
        presentation_header=b"uk_health_check_2024"
    )
    
    # UK Border verifies both documents
    passport_verification_uk = uk_border.verify_presentation(
        proof=passport_proof_uk,
        disclosed_messages=passport_disclosed_uk,
        disclosed_indices=passport_indices_uk,
        presentation_header=b"uk_border_entry_2024",
        issuer_id="French Government",
        requirements={'required_attributes': ['full_name', 'nationality'], 'purpose': 'border_entry'}
    )
    
    health_verification_uk = uk_border.verify_presentation(
        proof=health_proof_uk,
        disclosed_messages=health_disclosed_uk,
        disclosed_indices=health_indices_uk,
        presentation_header=b"uk_health_check_2024",
        issuer_id="French Health Authority",
        requirements={'required_attributes': ['vaccine_name', 'vaccination_date'], 'purpose': 'health_check'}
    )
    
    assert passport_verification_uk['valid'], "UK passport verification should succeed"
    assert health_verification_uk['valid'], "UK health verification should succeed"
    print("[SUCCESS] UK Border Control: Entry approved")
    
    # STEP 2: Airline check-in
    print("\n2. Air France Check-in")
    
    passport_proof_airline, passport_disclosed_airline, passport_indices_airline = alice.create_presentation(
        credential_id="french_passport",
        issuer_pk=french_govt.public_key,
        attributes_to_reveal=['full_name', 'nationality'],
        presentation_header=b"airline_checkin_2024"
    )
    
    # Airline verifies passport for flight booking
    passport_verification_airline = airline.verify_presentation(
        proof=passport_proof_airline,
        disclosed_messages=passport_disclosed_airline,
        disclosed_indices=passport_indices_airline,
        presentation_header=b"airline_checkin_2024",
        issuer_id="French Government",
        requirements={'required_attributes': ['full_name', 'nationality'], 'purpose': 'flight_checkin'}
    )
    
    assert passport_verification_airline['valid'], "Airline passport verification should succeed"
    print("[SUCCESS] Air France: Check-in approved")
    
    # === PRIVACY ANALYSIS ===
    print("\n--- Privacy Analysis ---")
    print("Privacy preservation achieved throughout journey:")
    print("• UK Border: Saw nationality, name, health status - NOT passport number or birth place")
    print("• Airline: Saw basic identity for booking - NOT health data or passport number")
    print("[OK] Each verifier saw only what was necessary for their specific purpose")
    
    print("\n[SUCCESS] COMPLETE TRAVEL WORKFLOW SUCCESSFUL")
    print(f"[OK] Used {len(alice.credentials)} different credentials")
    print(f"[OK] Interacted with {2} different verifiers")
    print(f"[OK] Each verification used selective disclosure for privacy")
    
    return True


def test_multi_issuer_scenario():
    """Test scenario with multiple issuers and cross-verification"""
    print("\n=== Testing Multi-Issuer Scenario ===")
    print("Scenario: International student with credentials from multiple institutions")
    
    # === SETUP ===
    print("\n--- Setup: Multiple Institutions ---")
    
    # Issuers from different institutions
    germany_govt = DTCIssuer("German Government")
    france_univ = DTCIssuer("Université de Paris")
    
    # Student holder
    student = DTCHolder("Hans Mueller")
    
    # International verifier
    french_border = DTCVerifier("French Border Control")
    french_border.add_trusted_issuer("German Government", germany_govt.public_key)
    french_border.add_trusted_issuer("Université de Paris", france_univ.public_key)
    
    print("[OK] Created multi-institution issuer and verifier network")
    
    # === CREDENTIAL ISSUANCE ===
    print("\n--- Multi-Institution Credential Issuance ---")
    
    # 1. German passport
    german_passport = germany_govt.issue_credential(
        document_type=DocumentType.PASSPORT,
        attributes={
            'full_name': 'Hans Friedrich Mueller',
            'date_of_birth': '2000-08-15',
            'nationality': 'German',
            'passport_number': 'DE456789123',
            'issuing_authority': 'Bundesrepublik Deutschland',
            'issue_date': '2023-03-20',
            'expiry_date': '2033-03-20',
            'place_of_birth': 'Munich, Germany'
        },
        holder_id="hans@student.de"
    )
    student.store_credential("german_passport", german_passport)
    
    # 2. French university enrollment certificate (using vaccination document type as placeholder)
    enrollment_cert = france_univ.issue_credential(
        document_type=DocumentType.VACCINATION,
        attributes={
            'student_name': 'Hans Friedrich Mueller',
            'student_id': 'UP2024789456',
            'program': 'Master of Computer Science',
            'enrollment_date': '2024-09-01',
            'expected_graduation': '2026-06-30',
            'academic_standing': 'Good Standing',
            'institution': 'Université de Paris'
        },
        holder_id="hans@student.de"
    )
    student.store_credential("enrollment_certificate", enrollment_cert)
    
    print("[OK] Issued credentials from 2 different institutions")
    
    # === CROSS-INSTITUTIONAL VERIFICATION ===
    print("\n--- Cross-Institutional Verification ---")
    
    # French border needs to verify:
    # 1. German passport (identity)
    # 2. French university enrollment (study purpose)
    
    # Passport presentation
    passport_proof, passport_disclosed, passport_indices = student.create_presentation(
        credential_id="german_passport",
        issuer_pk=germany_govt.public_key,
        attributes_to_reveal=['full_name', 'nationality', 'expiry_date'],
        presentation_header=b"france_student_entry_2024"
    )
    
    # University enrollment presentation
    enrollment_proof, enrollment_disclosed, enrollment_indices = student.create_presentation(
        credential_id="enrollment_certificate",
        issuer_pk=france_univ.public_key,
        attributes_to_reveal=['student_name', 'program', 'academic_standing'],
        presentation_header=b"france_student_entry_2024"
    )
    
    # French border verifies both documents
    passport_verification = french_border.verify_presentation(
        proof=passport_proof,
        disclosed_messages=passport_disclosed,
        disclosed_indices=passport_indices,
        presentation_header=b"france_student_entry_2024",
        issuer_id="German Government",
        requirements={'required_attributes': ['full_name', 'nationality'], 'purpose': 'identity_verification'}
    )
    
    enrollment_verification = french_border.verify_presentation(
        proof=enrollment_proof,
        disclosed_messages=enrollment_disclosed,
        disclosed_indices=enrollment_indices,
        presentation_header=b"france_student_entry_2024",
        issuer_id="Université de Paris",
        requirements={'required_attributes': ['student_name', 'program'], 'purpose': 'study_verification'}
    )
    
    # Verify all documents passed
    assert passport_verification['valid'], "German passport should verify"
    assert enrollment_verification['valid'], "French university enrollment should verify"
    
    print("[SUCCESS] Multi-issuer verification successful:")
    print("  • German passport verified")
    print("  • French university enrollment verified")
    print("[OK] International student entry to France approved")
    
    return True


def test_privacy_compliance():
    """Test privacy compliance across different scenarios"""
    print("\n=== Testing Privacy Compliance ===")
    print("Scenario: Same person, different contexts with different privacy requirements")
    
    # === SETUP ===
    govt_issuer = DTCIssuer("Digital Government")
    citizen = DTCHolder("Privacy-Conscious Citizen")
    
    # Different verifiers with different privacy requirements
    age_verifier = DTCVerifier("Age Verification Service")  # Only needs age proof
    age_verifier.add_trusted_issuer("Digital Government", govt_issuer.public_key)
    
    travel_verifier = DTCVerifier("International Airport")  # Needs full identity
    travel_verifier.add_trusted_issuer("Digital Government", govt_issuer.public_key)
    
    print("[OK] Created privacy-focused scenario with different verification needs")
    
    # === CREDENTIAL ISSUANCE ===
    print("\n--- Privacy-Sensitive Credential Issuance ---")
    
    # Identity document with sensitive information
    identity_doc = govt_issuer.issue_credential(
        document_type=DocumentType.PASSPORT,
        attributes={
            'full_name': 'Jordan Privacy Smith',
            'date_of_birth': '1985-12-10',     # Sensitive: exact age
            'nationality': 'Digital Nation',
            'passport_number': 'DN123456789',  # Very sensitive
            'address': '123 Private Street',   # Sensitive location
            'issuing_authority': 'Digital Government'
        },
        holder_id="jordan@privacy.example"
    )
    citizen.store_credential("identity", identity_doc)
    print("[OK] Issued credential with sensitive information")
    
    # === PRIVACY-PRESERVING PRESENTATIONS ===
    print("\n--- Privacy-Preserving Presentations ---")
    
    # SCENARIO 1: Age verification (minimal disclosure)
    print("\n1. Age Verification - Minimal Disclosure")
    age_proof, age_disclosed, age_indices = citizen.create_presentation(
        credential_id="identity",
        issuer_pk=govt_issuer.public_key,
        attributes_to_reveal=['date_of_birth'],  # Only birth date for age calculation
        presentation_header=b"age_verification_minimal"
    )
    
    age_verification = age_verifier.verify_presentation(
        proof=age_proof,
        disclosed_messages=age_disclosed,
        disclosed_indices=age_indices,
        presentation_header=b"age_verification_minimal",
        issuer_id="Digital Government",
        requirements={'required_attributes': ['date_of_birth'], 'purpose': 'age_check'}
    )
    
    assert age_verification['valid'], "Age verification should succeed"
    print("[SUCCESS] Age verified with minimal disclosure (only birth date, not name/address/passport)")
    
    # SCENARIO 2: International travel (more disclosure needed)
    print("\n2. International Travel - Identity-Focused Disclosure")
    travel_proof, travel_disclosed, travel_indices = citizen.create_presentation(
        credential_id="identity",
        issuer_pk=govt_issuer.public_key,
        attributes_to_reveal=['full_name', 'nationality', 'passport_number'],  # Travel essentials
        presentation_header=b"international_travel_2024"
    )
    
    travel_verification = travel_verifier.verify_presentation(
        proof=travel_proof,
        disclosed_messages=travel_disclosed,
        disclosed_indices=travel_indices,
        presentation_header=b"international_travel_2024",
        issuer_id="Digital Government",
        requirements={'required_attributes': ['full_name', 'nationality'], 'purpose': 'travel_identity'}
    )
    
    assert travel_verification['valid'], "Travel verification should succeed"
    print("[SUCCESS] Travel verified (revealed travel essentials, hid address and birth date)")
    
    # === PRIVACY COMPLIANCE SUMMARY ===
    print("\n--- Privacy Compliance Analysis ---")
    print("[SUCCESS] Same person, two different contexts:")
    print("  1. Age check: Revealed ONLY birth date (not name, passport, or address)")
    print("  2. Travel: Revealed ONLY travel-essential identity (not address or birth date)")
    print("")
    print("[SUCCESS] Privacy compliance achieved:")
    print("  • Data minimization: Each verifier saw only what they needed")
    print("  • Purpose limitation: Same credential, different disclosures per purpose")
    print("  • Selective disclosure: Sensitive details hidden when not needed")
    
    return True


def run_all_flow_tests():
    """Run all integration flow tests"""
    print("\n" + "="*70)
    print(" COMPREHENSIVE INTEGRATION FLOW TESTS")
    print("="*70)
    
    tests = [
        ("Complete Travel Workflow", test_complete_travel_workflow),
        ("Multi-Issuer Scenario", test_multi_issuer_scenario),
        ("Privacy Compliance", test_privacy_compliance)
    ]
    
    results = []
    start_time = time.time()
    
    for test_name, test_func in tests:
        print(f"\n{'='*50}")
        print(f"Running: {test_name}")
        print('='*50)
        
        test_start = time.time()
        try:
            result = test_func()
            test_time = time.time() - test_start
            results.append((test_name, "PASSED", test_time))
            print(f"\n[SUCCESS] {test_name}: PASSED ({test_time:.3f}s)")
        except Exception as e:
            test_time = time.time() - test_start
            error_msg = str(e)
            results.append((test_name, f"FAILED: {error_msg}", test_time))
            print(f"\n[ERROR] {test_name}: FAILED ({test_time:.3f}s)")
            print(f"   Error: {error_msg}")
    
    total_time = time.time() - start_time
    
    # Summary
    print("\n" + "="*70)
    print(" INTEGRATION FLOW TEST SUMMARY")
    print("="*70)
    
    passed = sum(1 for _, status, _ in results if status == "PASSED")
    total = len(results)
    
    for test_name, status, test_time in results:
        symbol = "[SUCCESS]" if status == "PASSED" else "[ERROR]"
        time_str = f"({test_time:.3f}s)"
        print(f"{symbol} {test_name:.<40} {status} {time_str}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    print(f"Total time: {total_time:.3f}s")
    print(f"Average time per test: {total_time/total:.3f}s")
    
    if passed == total:
        print("\n[SUCCESS] ALL INTEGRATION TESTS PASSED! End-to-end workflows working correctly.")
    else:
        print(f"\n[WARNING]  {total - passed} test(s) failed. Please check the implementation.")
    
    return passed == total


if __name__ == "__main__":
    success = run_all_flow_tests()
    exit(0 if success else 1)