"""
Tests for BBS Blind Signature implementation
Tests the privacy-preserving issuance using blind signatures
"""

import sys
import os
import time
from typing import List, Tuple

# Add the parent directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from BBSCore.KeyGen import BBSKeyGen
from BBSCore.BlindSign import BBSBlindSigner
from BBSCore.bbsSign import BBSSignatureScheme
from DTC.DTCIssuer import DTCIssuer
from DTC.DTCHolder import DTCHolder
from DTC.dtc import DocumentType


def test_blind_signature_protocol():
    """Test the basic blind signature protocol"""
    print("\n=== Testing Blind Signature Protocol ===")
    
    # Setup
    blind_scheme = BBSBlindSigner()
    sk, pk = BBSKeyGen.generate_keypair()
    
    # Holder's messages (some known to issuer, some blinded)
    messages = [
        b"public:document_type:passport",
        b"public:issuing_authority:French_Government",  # Known to issuer
        b"private:full_name:Alice_Dubois",              # Blinded from issuer
        b"private:passport_number:FR123456789"          # Blinded from issuer
    ]
    
    # Define which messages are known to issuer vs blinded
    known_message_indices = [0, 1]  # First two messages known to issuer
    
    print(f"[OK] Setup: {len(messages)} total messages, {len(known_message_indices)} known to issuer")
    
    # === HOLDER: Create commitment and proof ===
    commitment, commitment_proof, blinding_factor = blind_scheme.create_commitment(
        messages, known_message_indices
    )
    print("[OK] Holder created commitment and proof")
    
    # === ISSUER: Verify commitment and create blind signature ===
    # Issuer knows only the public messages
    known_messages = [messages[i] for i in known_message_indices]
    
    # Verify the commitment proof
    is_commitment_valid = blind_scheme.verify_commitment(
        pk, commitment, commitment_proof, known_messages, known_message_indices
    )
    assert is_commitment_valid, "Commitment proof verification failed"
    print("[OK] Issuer verified commitment proof")
    
    # Issuer creates blind signature
    blind_signature = blind_scheme.blind_sign(sk, commitment, known_messages, known_message_indices)
    print("[OK] Issuer created blind signature")
    
    # === HOLDER: Unblind signature ===
    signature = blind_scheme.unblind_signature(blind_signature, blinding_factor)
    print("[OK] Holder unblinded signature")
    
    # === VERIFICATION ===
    # Verify the final signature works with all messages
    bbs = BBSSignatureScheme()
    is_signature_valid = bbs.verify(pk, signature, messages)
    assert is_signature_valid, "Unblinded signature verification failed"
    print("[OK] Unblinded signature verified successfully")
    
    return True


def test_privacy_preservation():
    """Test that blind signatures preserve privacy"""
    print("\n=== Testing Privacy Preservation ===")
    
    # Setup
    blind_scheme = BBSBlindSigner()
    sk, pk = BBSKeyGen.generate_keypair()
    
    # Scenario: Two users with same public attributes but different private attributes
    alice_messages = [
        b"public:document_type:passport",
        b"public:country:France",
        b"private:name:Alice_Dubois",
        b"private:passport:FR111111"
    ]
    
    bob_messages = [
        b"public:document_type:passport", 
        b"public:country:France",
        b"private:name:Bob_Martin",
        b"private:passport:FR222222"
    ]
    
    known_indices = [0, 1]  # Only document type and country known to issuer
    
    # === ALICE'S BLIND ISSUANCE ===
    alice_commitment, alice_proof, alice_blinding = blind_scheme.create_commitment(
        alice_messages, known_indices
    )
    
    known_msgs = [alice_messages[i] for i in known_indices]
    alice_blind_sig = blind_scheme.blind_sign(sk, alice_commitment, known_msgs, known_indices)
    alice_signature = blind_scheme.unblind_signature(alice_blind_sig, alice_blinding)
    print("[OK] Alice received blind signature")
    
    # === BOB'S BLIND ISSUANCE ===
    bob_commitment, bob_proof, bob_blinding = blind_scheme.create_commitment(
        bob_messages, known_indices
    )
    
    bob_blind_sig = blind_scheme.blind_sign(sk, bob_commitment, known_msgs, known_indices)
    bob_signature = blind_scheme.unblind_signature(bob_blind_sig, bob_blinding)
    print("[OK] Bob received blind signature")
    
    # === PRIVACY CHECK ===
    # The issuer saw the same public information for both Alice and Bob
    # but cannot link the final signatures to specific individuals
    
    # Verify both signatures work
    bbs = BBSSignatureScheme()
    alice_valid = bbs.verify(pk, alice_signature, alice_messages)
    bob_valid = bbs.verify(pk, bob_signature, bob_messages)
    
    assert alice_valid, "Alice's signature should be valid"
    assert bob_valid, "Bob's signature should be valid"
    print("[OK] Both signatures verify correctly")
    
    # Check that commitments don't reveal private information
    # (This is a conceptual check - in practice, commitments are cryptographically hiding)
    assert alice_commitment != bob_commitment, "Commitments should be different (unlinkable)"
    print("[OK] Commitments are unlinkable (different values)")
    
    print("[OK] Privacy preserved: issuer cannot link signatures to individuals")
    
    return True


def test_blind_dtc_integration():
    """Test blind signature integration with DTC system"""
    print("\n=== Testing Blind Signature DTC Integration ===")
    
    # Note: This tests the integration concept since full blind DTC
    # implementation may still be in development
    
    # Setup DTC actors
    issuer = DTCIssuer("Privacy-Preserving Government")
    holder = DTCHolder("Anonymous Citizen")
    
    print("[OK] Created privacy-preserving DTC issuer and holder")
    
    # Test that regular DTC workflow still works (foundation for blind implementation)
    passport_attrs = {
        'full_name': 'Test User',
        'date_of_birth': '1990-01-01',
        'nationality': 'French',
        'passport_number': 'FR123456789',
        'issuing_authority': 'République Française',
        'issue_date': '2024-01-01',
        'expiry_date': '2034-01-01',
        'place_of_birth': 'Paris, France'
    }
    
    # Issue regular credential (blind issuance would build on this)
    credential = issuer.issue_credential(
        document_type=DocumentType.PASSPORT,
        attributes=passport_attrs,
        holder_id="test_user"
    )
    print("[OK] Regular credential issuance working (foundation for blind issuance)")
    
    # Store and test presentation
    holder.store_credential("test_passport", credential)
    
    proof, disclosed, indices = holder.create_presentation(
        credential_id="test_passport",
        issuer_pk=issuer.public_key,
        attributes_to_reveal=['nationality', 'issuing_authority'],
        presentation_header=b"integration_test"
    )
    
    assert proof is not None, "Presentation should work"
    assert len(disclosed) == 2, "Should have correct number of disclosed attributes"
    print("[OK] Credential presentation working (selective disclosure foundation)")
    
    print("[OK] DTC system ready for blind signature integration")
    return True


def run_all_blind_tests():
    """Run all blind signature tests"""
    print("\n" + "="*70)
    print(" COMPREHENSIVE BBS BLIND SIGNATURE TESTS")
    print("="*70)
    
    tests = [
        ("Blind Signature Protocol", test_blind_signature_protocol),
        ("Privacy Preservation", test_privacy_preservation),
        ("Blind DTC Integration", test_blind_dtc_integration)
    ]
    
    results = []
    start_time = time.time()
    
    for test_name, test_func in tests:
        print(f"\n{'='*50}")
        print(f"Running: {test_name}")
        print('='*50)
        
        test_start = time.time()
        try:
            result = test_func()
            test_time = time.time() - test_start
            results.append((test_name, "PASSED", test_time))
            print(f"\n[SUCCESS] {test_name}: PASSED ({test_time:.3f}s)")
        except Exception as e:
            test_time = time.time() - test_start
            error_msg = str(e)
            results.append((test_name, f"FAILED: {error_msg}", test_time))
            print(f"\n[ERROR] {test_name}: FAILED ({test_time:.3f}s)")
            print(f"   Error: {error_msg}")
    
    total_time = time.time() - start_time
    
    # Summary
    print("\n" + "="*70)
    print(" BLIND SIGNATURE TEST SUMMARY")
    print("="*70)
    
    passed = sum(1 for _, status, _ in results if status == "PASSED")
    total = len(results)
    
    for test_name, status, test_time in results:
        symbol = "[SUCCESS]" if status == "PASSED" else "[ERROR]"
        time_str = f"({test_time:.3f}s)"
        print(f"{symbol} {test_name:.<45} {status} {time_str}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    print(f"Total time: {total_time:.3f}s")
    print(f"Average time per test: {total_time/total:.3f}s")
    
    if passed == total:
        print("\n[SUCCESS] ALL BLIND SIGNATURE TESTS PASSED! Privacy-preserving issuance working correctly.")
    else:
        print(f"\n[WARNING]  {total - passed} test(s) failed. Please check the implementation.")
    
    return passed == total


if __name__ == "__main__":
    success = run_all_blind_tests()
    exit(0 if success else 1)