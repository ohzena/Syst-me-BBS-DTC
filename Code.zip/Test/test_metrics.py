"""
Performance benchmarks for BBS signature scheme and DTC implementation
Tests performance characteristics, scalability, and resource usage
"""

import sys
import os
import time
import statistics
from typing import List, Dict, Tuple

# Add the parent directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from BBSCore.KeyGen import BBSKeyGen
from BBSCore.bbsSign import BBSSignatureScheme
from DTC.DTCIssuer import DTCIssuer
from DTC.DTCHolder import DTCHolder
from DTC.DTCVerifier import DTCVerifier
from DTC.dtc import DocumentType


def benchmark_function(func, *args, iterations=10, warmup=2):
    """
    Benchmark a function with multiple iterations
    
    Returns:
        Dict with timing statistics
    """
    # Warmup runs
    for _ in range(warmup):
        try:
            func(*args)
        except:
            pass  # Ignore warmup errors
    
    # Actual benchmark runs
    times = []
    for _ in range(iterations):
        start_time = time.time()
        try:
            result = func(*args)
        except Exception as e:
            print(f"Benchmark function failed: {e}")
            continue
        end_time = time.time()
        times.append((end_time - start_time) * 1000)  # Convert to milliseconds
    
    if not times:
        return {
            'mean_ms': 0,
            'median_ms': 0,
            'min_ms': 0,
            'max_ms': 0,
            'std_dev_ms': 0,
            'iterations': 0
        }
    
    return {
        'mean_ms': statistics.mean(times),
        'median_ms': statistics.median(times),
        'min_ms': min(times),
        'max_ms': max(times),
        'std_dev_ms': statistics.stdev(times) if len(times) > 1 else 0,
        'iterations': len(times)
    }


def test_signature_performance():
    """Benchmark BBS signature creation and verification performance"""
    print("\n=== BBS Signature Performance Benchmarks ===")
    
    # Setup
    bbs = BBSSignatureScheme(max_messages=50)
    sk, pk = BBSKeyGen.generate_keypair()
    
    # Test messages of varying sizes
    small_messages = [f"msg_{i}".encode() for i in range(5)]
    medium_messages = [f"attribute_{i}:value_{i}".encode() for i in range(15)]
    large_messages = [f"large_attribute_{i}:{'data' * 10}_{i}".encode() for i in range(30)]
    
    print("\n--- Key Generation Performance ---")
    keygen_stats = benchmark_function(BBSKeyGen.generate_keypair, iterations=10)
    print(f"Key Generation: {keygen_stats['mean_ms']:.2f}ms ± {keygen_stats['std_dev_ms']:.2f}ms")
    print(f"  Min: {keygen_stats['min_ms']:.2f}ms, Max: {keygen_stats['max_ms']:.2f}ms")
    
    print("\n--- Signature Creation Performance ---")
    
    # Small messages (5 attributes)
    small_sign_stats = benchmark_function(bbs.sign, sk, small_messages, iterations=10)
    print(f"Sign (5 messages): {small_sign_stats['mean_ms']:.2f}ms ± {small_sign_stats['std_dev_ms']:.2f}ms")
    
    # Medium messages (15 attributes)
    medium_sign_stats = benchmark_function(bbs.sign, sk, medium_messages, iterations=8)
    print(f"Sign (15 messages): {medium_sign_stats['mean_ms']:.2f}ms ± {medium_sign_stats['std_dev_ms']:.2f}ms")
    
    # Large messages (30 attributes)
    large_sign_stats = benchmark_function(bbs.sign, sk, large_messages, iterations=5)
    print(f"Sign (30 messages): {large_sign_stats['mean_ms']:.2f}ms ± {large_sign_stats['std_dev_ms']:.2f}ms")
    
    print("\n--- Signature Verification Performance ---")
    
    # Create signatures for verification testing
    small_sig = bbs.sign(sk, small_messages)
    medium_sig = bbs.sign(sk, medium_messages)
    large_sig = bbs.sign(sk, large_messages)
    
    # Verification benchmarks
    small_verify_stats = benchmark_function(bbs.verify, pk, small_sig, small_messages, iterations=10)
    print(f"Verify (5 messages): {small_verify_stats['mean_ms']:.2f}ms ± {small_verify_stats['std_dev_ms']:.2f}ms")
    
    medium_verify_stats = benchmark_function(bbs.verify, pk, medium_sig, medium_messages, iterations=10)
    print(f"Verify (15 messages): {medium_verify_stats['mean_ms']:.2f}ms ± {medium_verify_stats['std_dev_ms']:.2f}ms")
    
    large_verify_stats = benchmark_function(bbs.verify, pk, large_sig, large_messages, iterations=8)
    print(f"Verify (30 messages): {large_verify_stats['mean_ms']:.2f}ms ± {large_verify_stats['std_dev_ms']:.2f}ms")
    
    # Performance analysis
    print("\n--- Performance Analysis ---")
    print(f"[OK] Key generation: ~{keygen_stats['mean_ms']:.1f}ms per keypair")
    print(f"[OK] Signature scaling: {small_sign_stats['mean_ms']:.1f}ms (5 msgs) → {large_sign_stats['mean_ms']:.1f}ms (30 msgs)")
    print(f"[OK] Verification scaling: {small_verify_stats['mean_ms']:.1f}ms (5 msgs) → {large_verify_stats['mean_ms']:.1f}ms (30 msgs)")
    
    if small_sign_stats['mean_ms'] > 0:
        scaling_factor_sign = large_sign_stats['mean_ms'] / small_sign_stats['mean_ms']
        print(f"[OK] Signature scaling factor (6x messages): {scaling_factor_sign:.1f}x")
    
    if small_verify_stats['mean_ms'] > 0:
        scaling_factor_verify = large_verify_stats['mean_ms'] / small_verify_stats['mean_ms']
        print(f"[OK] Verification scaling factor (6x messages): {scaling_factor_verify:.1f}x")
    
    return {
        'keygen_ms': keygen_stats['mean_ms'],
        'sign_5_msgs': small_sign_stats['mean_ms'],
        'sign_30_msgs': large_sign_stats['mean_ms'],
        'verify_5_msgs': small_verify_stats['mean_ms'],
        'verify_30_msgs': large_verify_stats['mean_ms']
    }


def test_dtc_workflow_performance():
    """Benchmark complete DTC workflow performance"""
    print("\n=== DTC Workflow Performance Benchmarks ===")
    
    # Setup actors
    issuer = DTCIssuer("Benchmark Government")
    holder = DTCHolder("Benchmark Citizen")
    verifier = DTCVerifier("Benchmark Verifier")
    verifier.add_trusted_issuer("Benchmark Government", issuer.public_key)
    
    # Test credential data
    passport_data = {
        'full_name': 'Performance Test User',
        'date_of_birth': '1990-01-01',
        'nationality': 'Benchmark Nation',
        'passport_number': 'BN123456789',
        'issuing_authority': 'Benchmark Government',
        'issue_date': '2024-01-01',
        'expiry_date': '2034-01-01',
        'place_of_birth': 'Benchmark City'
    }
    
    print("\n--- Credential Issuance Performance ---")
    
    def issue_credential():
        return issuer.issue_credential(
            document_type=DocumentType.PASSPORT,
            attributes=passport_data,
            holder_id="benchmark@test.com"
        )
    
    issuance_stats = benchmark_function(issue_credential, iterations=8)
    print(f"Credential Issuance: {issuance_stats['mean_ms']:.2f}ms ± {issuance_stats['std_dev_ms']:.2f}ms")
    
    print("\n--- Credential Storage Performance ---")
    
    # Issue a credential for storage testing
    test_credential = issue_credential()
    
    def store_credential():
        holder.store_credential(f"benchmark_{time.time()}", test_credential)
    
    storage_stats = benchmark_function(store_credential, iterations=15)
    print(f"Credential Storage: {storage_stats['mean_ms']:.2f}ms ± {storage_stats['std_dev_ms']:.2f}ms")
    
    print("\n--- Presentation Creation Performance ---")
    
    # Store credential for presentation testing
    holder.store_credential("benchmark_passport", test_credential)
    
    def create_presentation():
        return holder.create_presentation(
            credential_id="benchmark_passport",
            issuer_pk=issuer.public_key,
            attributes_to_reveal=['full_name', 'nationality', 'expiry_date'],
            presentation_header=b"benchmark_presentation"
        )
    
    presentation_stats = benchmark_function(create_presentation, iterations=8)
    print(f"Presentation Creation: {presentation_stats['mean_ms']:.2f}ms ± {presentation_stats['std_dev_ms']:.2f}ms")
    
    print("\n--- Presentation Verification Performance ---")
    
    # Create presentation for verification testing
    proof, disclosed_messages, disclosed_indices = create_presentation()
    
    def verify_presentation():
        return verifier.verify_presentation(
            proof=proof,
            disclosed_messages=disclosed_messages,
            disclosed_indices=disclosed_indices,
            presentation_header=b"benchmark_presentation",
            issuer_id="Benchmark Government",
            requirements={'required_attributes': ['full_name', 'nationality'], 'purpose': 'benchmark'}
        )
    
    verification_stats = benchmark_function(verify_presentation, iterations=10)
    print(f"Presentation Verification: {verification_stats['mean_ms']:.2f}ms ± {verification_stats['std_dev_ms']:.2f}ms")
    
    # Complete workflow benchmark
    print("\n--- Complete Workflow Performance ---")
    
    def complete_workflow():
        # Issuance
        cred = issuer.issue_credential(DocumentType.PASSPORT, passport_data, "test@example.com")
        # Storage
        holder.store_credential(f"workflow_{time.time()}", cred)
        # Presentation
        proof, disclosed, indices = holder.create_presentation(
            f"workflow_{time.time()-1}", issuer.public_key, ['full_name', 'nationality'], b"workflow_test"
        )
        # Verification
        result = verifier.verify_presentation(
            proof, disclosed, indices, b"workflow_test", "Benchmark Government",
            {'required_attributes': ['full_name'], 'purpose': 'test'}
        )
        return result['valid']
    
    workflow_stats = benchmark_function(complete_workflow, iterations=5)
    print(f"Complete Workflow: {workflow_stats['mean_ms']:.2f}ms ± {workflow_stats['std_dev_ms']:.2f}ms")
    
    # Performance breakdown
    total_components = issuance_stats['mean_ms'] + storage_stats['mean_ms'] + presentation_stats['mean_ms'] + verification_stats['mean_ms']
    print(f"\n--- DTC Workflow Analysis ---")
    print(f"[OK] Component breakdown: {total_components:.1f}ms total")
    if total_components > 0:
        print(f"  • Issuance: {issuance_stats['mean_ms']:.1f}ms ({issuance_stats['mean_ms']/total_components*100:.1f}%)")
        print(f"  • Storage: {storage_stats['mean_ms']:.1f}ms ({storage_stats['mean_ms']/total_components*100:.1f}%)")
        print(f"  • Presentation: {presentation_stats['mean_ms']:.1f}ms ({presentation_stats['mean_ms']/total_components*100:.1f}%)")
        print(f"  • Verification: {verification_stats['mean_ms']:.1f}ms ({verification_stats['mean_ms']/total_components*100:.1f}%)")
    print(f"[OK] End-to-end workflow: {workflow_stats['mean_ms']:.1f}ms")
    
    return {
        'issuance_ms': issuance_stats['mean_ms'],
        'storage_ms': storage_stats['mean_ms'],
        'presentation_ms': presentation_stats['mean_ms'],
        'verification_ms': verification_stats['mean_ms'],
        'complete_workflow_ms': workflow_stats['mean_ms']
    }


def test_scalability():
    """Test scalability with increasing numbers of credentials and attributes"""
    print("\n=== Scalability Benchmarks ===")
    
    # Setup
    bbs = BBSSignatureScheme(max_messages=100)
    sk, pk = BBSKeyGen.generate_keypair()
    
    print("\n--- Message Count Scalability ---")
    
    message_counts = [5, 10, 20, 40]
    sign_times = []
    verify_times = []
    
    for count in message_counts:
        messages = [f"message_{i}:data_{i}".encode() for i in range(count)]
        
        # Signature time
        sign_stats = benchmark_function(bbs.sign, sk, messages, iterations=5)
        sign_times.append(sign_stats['mean_ms'])
        
        # Verification time
        signature = bbs.sign(sk, messages)
        verify_stats = benchmark_function(bbs.verify, pk, signature, messages, iterations=5)
        verify_times.append(verify_stats['mean_ms'])
        
        print(f"Messages: {count:2d} | Sign: {sign_stats['mean_ms']:6.1f}ms | Verify: {verify_stats['mean_ms']:6.1f}ms")
    
    print("\n--- Scalability Analysis ---")
    print("Message scaling (linear = 1.0, quadratic = 2.0):")
    
    # Calculate scaling factors
    if len(message_counts) > 1 and sign_times[0] > 0 and verify_times[0] > 0:
        for i in range(1, len(message_counts)):
            msg_ratio = message_counts[i] / message_counts[0]
            sign_ratio = sign_times[i] / sign_times[0]
            verify_ratio = verify_times[i] / verify_times[0]
            
            sign_scaling = sign_ratio / msg_ratio
            verify_scaling = verify_ratio / msg_ratio
            
            print(f"  {message_counts[0]}→{message_counts[i]} msgs: Sign scaling {sign_scaling:.2f}, Verify scaling {verify_scaling:.2f}")
        
        # Overall scaling assessment
        final_msg_ratio = message_counts[-1] / message_counts[0]
        final_sign_ratio = sign_times[-1] / sign_times[0]
        final_verify_ratio = verify_times[-1] / verify_times[0]
        
        overall_sign_scaling = final_sign_ratio / final_msg_ratio
        overall_verify_scaling = final_verify_ratio / final_msg_ratio
        
        print(f"\n[OK] Overall scaling ({message_counts[0]}→{message_counts[-1]} messages):")
        print(f"  • Signature: {overall_sign_scaling:.2f}x (1.0 = linear, <2.0 = sub-quadratic)")
        print(f"  • Verification: {overall_verify_scaling:.2f}x (1.0 = linear, <2.0 = sub-quadratic)")
        
        if overall_sign_scaling < 1.5 and overall_verify_scaling < 1.5:
            print("[SUCCESS] Excellent scalability: Near-linear performance")
        elif overall_sign_scaling < 2.5 and overall_verify_scaling < 2.5:
            print("[SUCCESS] Good scalability: Sub-quadratic performance") 
        else:
            print("[WARNING]  Scalability concern: Super-quadratic growth")
    else:
        overall_sign_scaling = 1.0
        overall_verify_scaling = 1.0
        print("[OK] Scalability analysis limited due to measurement constraints")
    
    return {
        'message_counts': message_counts,
        'sign_times': sign_times,
        'verify_times': verify_times,
        'sign_scaling': overall_sign_scaling,
        'verify_scaling': overall_verify_scaling
    }


def run_all_performance_tests():
    """Run all performance benchmarks"""
    print("\n" + "="*70)
    print(" COMPREHENSIVE PERFORMANCE BENCHMARKS")
    print("="*70)
    
    print("[TIME]  Running performance benchmarks... (this may take a few minutes)")
    
    benchmark_start = time.time()
    
    # Run benchmarks
    try:
        signature_metrics = test_signature_performance()
        dtc_metrics = test_dtc_workflow_performance()
        scalability_metrics = test_scalability()
        
        benchmark_end = time.time()
        total_benchmark_time = benchmark_end - benchmark_start
        
        # Performance summary
        print("\n" + "="*70)
        print(" PERFORMANCE SUMMARY")
        print("="*70)
        
        print("\n[KEY] BBS Signature Performance:")
        print(f"  • Key Generation: {signature_metrics['keygen_ms']:.1f}ms")
        print(f"  • Sign (5 msgs): {signature_metrics['sign_5_msgs']:.1f}ms")
        print(f"  • Sign (30 msgs): {signature_metrics['sign_30_msgs']:.1f}ms")
        print(f"  • Verify (5 msgs): {signature_metrics['verify_5_msgs']:.1f}ms")
        print(f"  • Verify (30 msgs): {signature_metrics['verify_30_msgs']:.1f}ms")
        
        print("\n[GOVERNMENT]  DTC Workflow Performance:")
        print(f"  • Credential Issuance: {dtc_metrics['issuance_ms']:.1f}ms")
        print(f"  • Credential Storage: {dtc_metrics['storage_ms']:.1f}ms")
        print(f"  • Presentation Creation: {dtc_metrics['presentation_ms']:.1f}ms")
        print(f"  • Presentation Verification: {dtc_metrics['verification_ms']:.1f}ms")
        print(f"  • Complete Workflow: {dtc_metrics['complete_workflow_ms']:.1f}ms")
        
        print("\n[GRAPH] Scalability:")
        print(f"  • Signature scaling: {scalability_metrics['sign_scaling']:.2f}x")
        print(f"  • Verification scaling: {scalability_metrics['verify_scaling']:.2f}x")
        
        print(f"\n[TIME]  Total benchmark time: {total_benchmark_time:.1f}s")
        
        # Performance assessment
        print("\n" + "="*70)
        print(" PERFORMANCE ASSESSMENT")
        print("="*70)
        
        # Assess if performance is suitable for practical use
        if (dtc_metrics['complete_workflow_ms'] < 1000 and 
            signature_metrics['sign_30_msgs'] < 500 and
            scalability_metrics['sign_scaling'] < 2.0):
            print("[SUCCESS] EXCELLENT PERFORMANCE: Suitable for production use")
            print("  • Sub-second end-to-end workflows")
            print("  • Efficient large-message signing")
            print("  • Good scalability characteristics")
        elif (dtc_metrics['complete_workflow_ms'] < 2000 and 
              signature_metrics['sign_30_msgs'] < 1000):
            print("[SUCCESS] GOOD PERFORMANCE: Suitable for most applications")
            print("  • Reasonable end-to-end performance")
            print("  • Acceptable signing overhead")
        else:
            print("[WARNING]  PERFORMANCE CONCERNS: May need optimization")
            print("  • Consider optimizing critical paths")
            print("  • May limit real-time applications")
        
        return True
        
    except Exception as e:
        print(f"\n[ERROR] Performance benchmark failed: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = run_all_performance_tests()
    exit(0 if success else 1)