"""
Comprehensive tests for Digital Trust Certificate (DTC) implementation
Tests the complete DTC workflow: issuance, storage, presentation, and verification
"""

import sys
import os
import time
from datetime import datetime, date
from typing import List, Dict, Any

# Add the parent directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from BBSCore.KeyGen import BBSKeyGen
from DTC.dtc import DTCCredential, DocumentType, AttributeType
from DTC.DTCIssuer import DTCIssuer
from DTC.DTCHolder import DTCHolder
from DTC.DTCVerifier import DTCVerifier


def test_credential_issuance():
    """Test DTC credential issuance functionality"""
    print("\n=== Testing Credential Issuance ===")
    
    # Setup issuer (French Government)
    issuer = DTCIssuer("French Government")
    print("[OK] Created issuer: French Government")
    
    # Test passport credential issuance
    passport_data = {
        'full_name': 'Alice Marie Dubois',
        'date_of_birth': '1995-03-15',
        'nationality': 'French',
        'passport_number': 'FR789456123',
        'issuing_authority': 'République Française',
        'issue_date': '2024-01-15',
        'expiry_date': '2034-01-15',
        'place_of_birth': 'Lyon, France'
    }
    
    passport_credential = issuer.issue_credential(
        document_type=DocumentType.PASSPORT,
        attributes=passport_data,
        holder_id="alice@example.com"
    )
    print("[OK] Passport credential issued successfully")
    
    # Verify credential structure
    assert passport_credential.document_type == DocumentType.PASSPORT, "Wrong document type"
    assert passport_credential.issuer_id == "French Government", "Wrong issuer"
    assert passport_credential.holder_id == "alice@example.com", "Wrong holder"
    assert len(passport_credential.attributes) == len(passport_data), "Wrong attribute count"
    print("[OK] Passport credential structure correct")
    
    return {
        'issuer': issuer,
        'passport': passport_credential
    }


def test_credential_storage():
    """Test DTC credential storage and management"""
    print("\n=== Testing Credential Storage ===")
    
    # Setup holder
    holder = DTCHolder("Alice Dubois")
    print("[OK] Created holder: Alice Dubois")
    
    # Issue credentials for testing
    test_data = test_credential_issuance()
    issuer = test_data['issuer']
    
    # Store passport credential
    passport_id = "passport_fr_alice_2024"
    holder.store_credential(passport_id, test_data['passport'])
    print("[OK] Stored passport credential")
    
    # Test credential listing
    credential_list = holder.list_credentials()
    assert len(credential_list) == 1, f"Expected 1 credential, got {len(credential_list)}"
    print(f"[OK] Credential list correct: {len(credential_list)} credentials")
    
    # Verify stored credentials
    assert passport_id in holder.credentials, "Passport credential not found"
    print("[OK] Credential properly stored and accessible")
    
    return {
        'holder': holder,
        'issuer': issuer,
        'passport_id': passport_id
    }


def test_selective_presentation():
    """Test DTC selective disclosure presentation"""
    print("\n=== Testing Selective Presentation ===")
    
    # Setup from previous test
    test_data = test_credential_storage()
    holder = test_data['holder']
    issuer = test_data['issuer']
    passport_id = test_data['passport_id']
    
    # Test passport selective disclosure
    # Reveal: name, nationality, expiry_date (hide: passport_number, place_of_birth, etc.)
    attributes_to_reveal = ['full_name', 'nationality', 'expiry_date']
    
    proof, disclosed_messages, disclosed_indices = holder.create_presentation(
        credential_id=passport_id,
        issuer_pk=issuer.public_key,
        attributes_to_reveal=attributes_to_reveal,
        presentation_header=b"border_control_verification_2024"
    )
    print(f"[OK] Created selective presentation revealing {len(attributes_to_reveal)} attributes")
    
    # Verify presentation structure
    assert proof is not None, "Proof generation failed"
    assert len(disclosed_messages) == len(attributes_to_reveal), "Wrong number of disclosed messages"
    assert len(disclosed_indices) == len(attributes_to_reveal), "Wrong number of disclosed indices"
    print("[OK] Presentation structure correct")
    
    return {
        'holder': holder,
        'issuer': issuer,
        'passport_presentation': {
            'proof': proof,
            'disclosed_messages': disclosed_messages,
            'disclosed_indices': disclosed_indices,
            'attributes_revealed': attributes_to_reveal,
            'header': b"border_control_verification_2024"
        }
    }


def test_credential_verification():
    """Test DTC credential verification"""
    print("\n=== Testing Credential Verification ===")
    
    # Setup from previous tests
    test_data = test_selective_presentation()
    issuer = test_data['issuer']
    passport_presentation = test_data['passport_presentation']
    
    # Setup verifiers
    border_control = DTCVerifier("UK Border Control")
    border_control.add_trusted_issuer("French Government", issuer.public_key)
    print("[OK] Created border control verifier")
    
    # Test passport presentation verification (Border Control)
    border_requirements = {
        'required_attributes': ['full_name', 'nationality', 'expiry_date'],
        'purpose': 'border_entry_verification'
    }
    
    passport_verification = border_control.verify_presentation(
        proof=passport_presentation['proof'],
        disclosed_messages=passport_presentation['disclosed_messages'],
        disclosed_indices=passport_presentation['disclosed_indices'],
        presentation_header=passport_presentation['header'],
        issuer_id="French Government",
        requirements=border_requirements
    )
    
    assert passport_verification['valid'] == True, "Passport verification should succeed"
    print("[OK] Passport presentation verified by Border Control")
    
    return True


def test_dtc_complete_flow():
    """Test complete end-to-end DTC workflow"""
    print("\n=== Testing Complete DTC Flow ===")
    
    print("Scenario: Alice travels from France to UK")
    
    # === SETUP PHASE ===
    print("\n--- Setup Phase ---")
    
    # Issuers
    french_gov = DTCIssuer("French Government")
    print("[OK] Created issuer: French Government")
    
    # Holder
    alice = DTCHolder("Alice Dubois")
    print("[OK] Created holder: Alice Dubois")
    
    # Verifiers
    uk_border = DTCVerifier("UK Border Control")
    uk_border.add_trusted_issuer("French Government", french_gov.public_key)
    print("[OK] Created verifier: UK Border Control with trusted issuer")
    
    # === ISSUANCE PHASE ===
    print("\n--- Credential Issuance Phase ---")
    
    # Issue French passport
    passport_attrs = {
        'full_name': 'Alice Marie Dubois',
        'date_of_birth': '1995-03-15',
        'nationality': 'French',
        'passport_number': 'FR789456123',
        'issuing_authority': 'République Française',
        'issue_date': '2024-01-15',
        'expiry_date': '2034-01-15',
        'place_of_birth': 'Lyon, France'
    }
    
    passport = french_gov.issue_credential(
        document_type=DocumentType.PASSPORT,
        attributes=passport_attrs,
        holder_id="alice@example.fr"
    )
    print("[OK] French passport issued")
    
    # === STORAGE PHASE ===
    print("\n--- Credential Storage Phase ---")
    
    alice.store_credential("fr_passport_alice", passport)
    print("[OK] Credential stored in Alice's wallet")
    
    # === PRESENTATION PHASE ===
    print("\n--- Presentation Phase ---")
    
    # Create passport presentation (reveal identity info, hide sensitive details)
    passport_proof, passport_disclosed, passport_indices = alice.create_presentation(
        credential_id="fr_passport_alice",
        issuer_pk=french_gov.public_key,
        attributes_to_reveal=['full_name', 'nationality', 'expiry_date'],
        presentation_header=b"uk_border_entry_2024"
    )
    print("[OK] Passport presentation created (selective disclosure)")
    
    # === VERIFICATION PHASE ===
    print("\n--- Verification Phase ---")
    
    # UK Border Control verifies passport
    passport_verification = uk_border.verify_presentation(
        proof=passport_proof,
        disclosed_messages=passport_disclosed,
        disclosed_indices=passport_indices,
        presentation_header=b"uk_border_entry_2024",
        issuer_id="French Government",
        requirements={
            'required_attributes': ['full_name', 'nationality', 'expiry_date'],
            'purpose': 'border_entry'
        }
    )
    
    # === RESULTS ===
    print("\n--- Verification Results ---")
    
    assert passport_verification['valid'], "Passport verification failed"
    
    print("[SUCCESS] Passport verification: PASSED")
    print("[SUCCESS] Alice successfully enters UK with privacy-preserved credentials")
    
    # Verify privacy preservation
    print("\n--- Privacy Preservation Check ---")
    print("Passport - Revealed: name, nationality, expiry")
    print("Passport - Hidden: passport number, place of birth, issue date")
    print("[OK] Sensitive information successfully hidden using selective disclosure")
    
    return True


def run_all_dtc_tests():
    """Run all DTC layer tests"""
    print("\n" + "="*70)
    print(" COMPREHENSIVE DIGITAL TRUST CERTIFICATE TESTS")
    print("="*70)
    
    tests = [
        ("Credential Issuance", test_credential_issuance),
        ("Credential Storage", test_credential_storage),
        ("Selective Presentation", test_selective_presentation),
        ("Credential Verification", test_credential_verification),
        ("Complete DTC Flow", test_dtc_complete_flow)
    ]
    
    results = []
    start_time = time.time()
    
    for test_name, test_func in tests:
        print(f"\n{'='*50}")
        print(f"Running: {test_name}")
        print('='*50)
        
        test_start = time.time()
        try:
            result = test_func()
            test_time = time.time() - test_start
            results.append((test_name, "PASSED", test_time))
            print(f"\n[SUCCESS] {test_name}: PASSED ({test_time:.3f}s)")
        except Exception as e:
            test_time = time.time() - test_start
            error_msg = str(e)
            results.append((test_name, f"FAILED: {error_msg}", test_time))
            print(f"\n[ERROR] {test_name}: FAILED ({test_time:.3f}s)")
            print(f"   Error: {error_msg}")
            # Uncomment for debugging:
            # import traceback
            # traceback.print_exc()
    
    total_time = time.time() - start_time
    
    # Summary
    print("\n" + "="*70)
    print(" DTC TEST SUMMARY")
    print("="*70)
    
    passed = sum(1 for _, status, _ in results if status == "PASSED")
    total = len(results)
    
    for test_name, status, test_time in results:
        symbol = "[SUCCESS]" if status == "PASSED" else "[ERROR]"
        time_str = f"({test_time:.3f}s)"
        print(f"{symbol} {test_name:.<40} {status} {time_str}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    print(f"Total time: {total_time:.3f}s")
    print(f"Average time per test: {total_time/total:.3f}s")
    
    if passed == total:
        print("\n[SUCCESS] ALL DTC TESTS PASSED! Complete DTC implementation is working correctly.")
    else:
        print(f"\n[WARNING]  {total - passed} test(s) failed. Please check the implementation.")
    
    return passed == total


if __name__ == "__main__":
    success = run_all_dtc_tests()
    exit(0 if success else 1)