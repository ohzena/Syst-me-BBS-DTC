"""
benchmark.data - Gestion des donnees et configurations pour benchmarks BBS-DTC

Ce module fournit les outils pour:
- Charger et valider les configurations JSON
- Gerer les schemas de validation
- Creer des templates pour differents scenarios DTC
- Valider les donnees de benchmarks
"""

__version__ = "1.0.0"
__description__ = "Data management for BBS-DTC benchmarks"

try:
    from .manager import DataManager
    from .schemas import (
        SimpleValidator,
        ProfileAnalyzer
    )
    DATA_AVAILABLE = True
except ImportError as e:
    DATA_AVAILABLE = False
    print(f"Warning: Modules data non disponibles: {e}")
    
    class DataManager:
        def __init__(self):
            raise ImportError("DataManager non disponible")

__all__ = [
    'DataManager',
    'BenchmarkConfigSchema',
    'ScenarioConfigSchema', 
    'ResultsSchema',
    'ValidationHelpers',
    'ConfigValidator',
    'DATA_AVAILABLE',
    'create_default_dtc_config',
    'validate_dtc_scenario',
    'get_template_configs'
]

DEFAULT_TEMPLATES = {
    'travel_basic': {
        'name': 'Travel Credential Basic',
        'attributes': ['passport_number', 'nationality', 'birth_date', 'expiry_date'],
        'disclosure_patterns': [
            {'disclosed': ['nationality'], 'hidden': ['passport_number', 'birth_date', 'expiry_date']}
        ]
    },
    
    'identity_simple': {
        'name': 'Identity Verification Simple',
        'attributes': ['full_name', 'birth_date', 'id_number', 'address'],
        'disclosure_patterns': [
            {'disclosed': ['full_name'], 'hidden': ['birth_date', 'id_number', 'address']}
        ]
    },
    
    'business_executive': {
        'name': 'Business Executive Travel',
        'attributes': ['full_name', 'company', 'job_title', 'visa_type', 'business_purpose'],
        'disclosure_patterns': [
            {'disclosed': ['full_name', 'company'], 'hidden': ['job_title', 'visa_type', 'business_purpose']}
        ]
    }
}

def create_default_dtc_config(template_type='basic'):
    """
    Cree une configuration DTC par defaut
    
    Args:
        template_type (str): Type de template ('basic', 'comprehensive', 'quick')
        
    Returns:
        dict: Configuration par defaut
    """
    if not DATA_AVAILABLE:
        return DEFAULT_TEMPLATES.get('travel_basic', {})
    
    manager = DataManager()
    return manager.create_template_config(template_type)

def validate_dtc_scenario(scenario_data):
    """
    Valide un scenario DTC
    
    Args:
        scenario_data (dict): Donnees du scenario a valider
        
    Returns:
        tuple: (is_valid, errors_list)
    """
    if not DATA_AVAILABLE:
        return True, []
    
    required_fields = ['name', 'attributes']
    errors = []
    
    for field in required_fields:
        if field not in scenario_data:
            errors.append(f"Missing required field: {field}")
    
    if not isinstance(scenario_data.get('attributes', []), list):
        errors.append("'attributes' must be a list")
    
    return len(errors) == 0, errors

def get_template_configs():
    """
    Retourne tous les templates de configuration disponibles
    
    Returns:
        dict: Templates disponibles par type
    """
    if not DATA_AVAILABLE:
        return DEFAULT_TEMPLATES
    
    templates = {}
    manager = DataManager()
    
    config_types = ['basic', 'comprehensive', 'quick']
    scenario_types = ['travel', 'identity', 'generic']
    
    for config_type in config_types:
        try:
            templates[f'config_{config_type}'] = manager.create_template_config(config_type)
        except:
            pass
    
    for scenario_type in scenario_types:
        try:
            templates[f'scenario_{scenario_type}'] = manager.create_template_scenario(scenario_type)
        except:
            pass
    
    return templates

def load_dtc_config(config_path):
    """
    Charge une configuration DTC depuis un fichier
    
    Args:
        config_path (str): Chemin vers le fichier JSON
        
    Returns:
        dict: Configuration chargee et validee
    """
    if not DATA_AVAILABLE:
        raise ImportError("DataManager non disponible")
    
    manager = DataManager()
    return manager.load_custom_config(config_path)

def save_dtc_config(config_data, filename):
    """
    Sauvegarde une configuration DTC
    
    Args:
        config_data (dict): Donnees de configuration
        filename (str): Nom du fichier de sortie
        
    Returns:
        str: Chemin du fichier sauvegarde
    """
    if not DATA_AVAILABLE:
        raise ImportError("DataManager non disponible")
    
    manager = DataManager()
    return manager.save_config(config_data, filename)

PACKAGE_INFO = {
    'name': 'benchmark.data',
    'version': __version__,
    'description': __description__,
    'dependencies': ['jsonschema (optional)'],
    'key_classes': ['DataManager', 'ConfigValidator'],
    'supported_formats': ['JSON'],
    'validation_types': ['benchmark_config', 'scenario_config', 'results']
}