"""
BBSCore - Core BBS Signature Scheme Implementation

This module provides the core BBS (Boneh-Boyen-Shacham) signature scheme
implementation for privacy-preserving digital signatures with selective disclosure.
"""

# Core BBS classes and functions
from .Setup import BBSPublicKey, BBSPrivateKey, BBSKeyPair, BBSSystemSetup, BBSGenerators
from .KeyGen import BBSKeyGen
from .bbsSign import BBSSignature, BBSSignatureScheme
from .BlindSign import BlindCommitment, BBSBlindSigner, BlindSignatureProtocol
from .ZKProof import BBSProof, BBSProofScheme

__all__ = [
    # Key management
    'BBSPublicKey',
    'BBSPrivateKey', 
    'BBSKeyPair',
    'BBSKeyGen',
    'BBSGenerators',
    'BBSSystemSetup',

    
    # Signature schemes
    'BBSSignature',
    'BBSSignatureScheme',
    'BlindCommitment', 
    'CommitmentProof',
    'BlindSignerClient',
    'BBSBlindSigner',
    'BlindSignatureProtocol',
    
    # Zero-knowledge proofs
    'ProofInitResult',
    'BBSProof',
    'BBSProofScheme',
    'BBSWithProofs'
]