"""
bbs_core.py - Unified BBS Interface

Provides a unified interface to all BBS components
"""

import sys
import os

project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

try:
    from BBSCore.Setup import (
        BBSPrivateKey, BBSPublicKey, BBSKeyPair, BBSSystemSetup, BBSGenerators,
        CURVE_ORDER, DST_KEYGEN, calculate_domain, hash_to_scalar
    )
    
    from BBSCore.KeyGen import BBSKeyGen
    from BBSCore.bbsSign import BBSSignatureScheme, BBSSignature
    from BBSCore.ZKProof import BBSProof, BBSProofScheme, BBSWithProofs
    
    BBS_AVAILABLE = True
    
except ImportError as e:
    BBS_AVAILABLE = False
    
    class BBSPrivateKey:
        def __init__(self, x: int):
            self.x = x
    
    class BBSPublicKey:
        def __init__(self, W):
            self.W = W
        
        def to_bytes(self) -> bytes:
            return b'mock_pubkey_96_bytes' + b'\x00' * 84
        
        def to_base58(self) -> str:
            return "mock_base58_pubkey"
    
    class BBSKeyPair:
        def __init__(self, secret_key, public_key):
            self.secret_key = secret_key
            self.public_key = public_key
    
    class BBSKeyGen:
        @staticmethod
        def keygen():
            return BBSKeyPair(BBSPrivateKey(123), BBSPublicKey(None))
        
        @staticmethod
        def generate_keypair():
            kp = BBSKeyGen.keygen()
            return kp.secret_key, kp.public_key
    
    class BBSSignature:
        def __init__(self, A=None, e=None):
            self.A = A
            self.e = e or 12345
        
        def to_bytes(self) -> bytes:
            return b'mock_signature_80_bytes' + b'\x00' * 60
        
        @classmethod
        def from_bytes(cls, data: bytes):
            return cls()
    
    class BBSProof:

        def __init__(self):
            pass
        
        def to_bytes(self) -> bytes:
            return b'mock_proof_data' + b'\x00' * 100

    class BBSSignatureScheme:
        def __init__(self, max_messages=30, api_id=b""):
            self.max_messages = max_messages
            self.api_id = api_id

        def core_proof_gen(self, pk, signature, header, messages, disclosed_indexes):
            """Redirection vers proof scheme"""
            if not hasattr(self, 'proof_scheme'):
                self.proof_scheme = BBSProofScheme(self.max_messages, self.api_id, self.generators)
            return self.proof_scheme.core_proof_gen(pk, signature, header, b"", messages, disclosed_indexes)

    class BBSWithProofs:
        def __init__(self, max_messages=30, api_id=b""):
            self.max_messages = max_messages
            self.api_id = api_id
        
        def sign(self, sk, messages, header):
            return BBSSignature()
        
        def verify(self, pk, signature, messages, header):
            return True
        
        def generate_proof(self, pk, signature, header, messages, disclosed_indices, presentation_header):
            return BBSProof()
        
        def verify_proof(self, pk, proof, header, disclosed_messages, disclosed_indices, presentation_header):
            return True
        
        def core_proof_gen(self, pk, signature, header, messages, disclosed_indexes):
            """Redirection vers proof scheme"""
            if not hasattr(self, 'proof_scheme'):
                self.proof_scheme = BBSProofScheme(self.max_messages, self.api_id, self.generators)
            return self.proof_scheme.core_proof_gen(pk, signature, header, b"", messages, disclosed_indexes)        

def generate_keypair(seed: bytes = None):
    """Generate a BBS keypair"""
    if BBS_AVAILABLE:
        return BBSKeyGen.generate_keypair()
    else:
        kp = BBSKeyGen.keygen()
        return kp.secret_key, kp.public_key

def create_bbs_with_proofs(max_messages: int = 30, api_id: bytes = b""):
    """Create a BBS instance with proof support"""
    return BBSProofScheme(max_messages=max_messages, api_id=api_id)

__all__ = [
    'BBSPrivateKey', 'BBSPublicKey', 'BBSKeyPair', 'BBSKeyGen',
    'BBSSignature', 'BBSProof', 'BBSProofScheme', 'BBSWithProofs',
    'generate_keypair', 'create_bbs_with_proofs',
    'BBS_AVAILABLE'
]

__version__ = "1.0.0"