"""
DTCIssuer.py - Digital Trust Certificate Issuer Implementation

The DTCIssuer represents trusted authorities (governments, health organizations) that issue
verifiable travel credentials using BBS signatures. This component demonstrates how BBS 
enables privacy-preserving digital credentials through selective disclosure.

Key BBS Integration:
- Uses BBS signature scheme to sign credential attributes as separate messages
- Each credential attribute becomes a BBS message, enabling selective disclosure
- Issues credentials that holders can later present with zero-knowledge proofs
- Maintains cryptographic keys for BBS signature generation

The issuer signs a vector of messages representing credential attributes:
messages = [credential_id, document_type, issuer_id, issued_at, attr1, attr2, ...]
signature = BBS.Sign(secret_key, messages, header)

This allows holders to later prove possession of valid credentials while revealing
only specific attributes through BBS proof generation.
"""

import re
from typing import Dict, List, Optional, Any
from datetime import datetime, date
import logging

import sys
import os
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

try:
    from bbs_core import (
        BBSPrivateKey, BBSPublicKey, BBSKeyPair, BBSKeyGen,
        BBSSignature, BBSSignatureScheme,
        BBSProofScheme, generate_keypair
    )
except ImportError:
    try:
        from BBSCore.KeyGen import BBSKeyGen
        from BBSCore.Setup import BBSPrivateKey, BBSPublicKey, BBSKeyPair
        from BBSCore.bbsSign import BBSSignatureScheme, BBSSignature
        from BBSCore.ZKProof import BBSProofScheme, BBSWithProofs
    except ImportError:
        class BBSPrivateKey:
            def __init__(self, x: int):
                self.x = x
        
        class BBSPublicKey:
            def __init__(self, W):
                self.W = W
                
            def to_bytes(self) -> bytes:
                return b'mock_pubkey_96_bytes' + b'\x00' * 84
                
            def to_base58(self) -> str:
                return "mock_base58_pubkey"
        
        class BBSKeyPair:
            def __init__(self, secret_key, public_key):
                self.secret_key = secret_key
                self.public_key = public_key
        
        class BBSKeyGen:
            @staticmethod
            def keygen():
                return BBSKeyPair(BBSPrivateKey(123), BBSPublicKey(None))
        
        class BBSSignature:
            def __init__(self):
                pass
                
            def to_bytes(self) -> bytes:
                return b'mock_signature_80_bytes' + b'\x00' * 60
        
        class BBSProofScheme:
            def __init__(self, max_messages=30, api_id=b""):
                self.max_messages = max_messages
                self.api_id = api_id
                
            def sign(self, sk, messages, header):
                return BBSSignature()

from .dtc import (
    DTCCredential, DocumentType, AttributeType, CredentialAttribute,
    PASSPORT_SCHEMA, VISA_SCHEMA, VACCINATION_SCHEMA,
    PassportCredential, VisaCredential, VaccinationCredential
)

logger = logging.getLogger(__name__)


class DTCIssuer:
    """
    Digital Trust Certificate Issuer - Signs credentials using BBS signatures
    
    This class implements the issuer role in the BBS-based DTC system. It generates
    BBS keypairs and signs credential attributes as message vectors, enabling later
    selective disclosure by credential holders.
    """
    
    def __init__(self, issuer_id: str, max_messages: int = 30):
        """Initialize DTC Issuer with BBS signing capabilities"""
        self.issuer_id = issuer_id
        self.max_messages = max_messages
        
        # Generate BBS keypair for credential signing
        logger.info(f"Generating BBS keys for issuer: {issuer_id}")
        try:
            keypair = BBSKeyGen.keygen()
            self.secret_key = keypair.secret_key
            self.public_key = keypair.public_key
        except Exception as e:
            logger.warning(f"Failed to generate real BBS keys: {e}, using mock keys")
            self.secret_key = BBSPrivateKey(12345)
            self.public_key = BBSPublicKey(None)
        
        # Initialize BBS with ZK proof support for issuing signatures
        try:
            self.bbs = BBSWithProofs(max_messages=max_messages, api_id=issuer_id.encode())
        except Exception as e:
            logger.warning(f"Failed to initialize BBSWithProofs: {e}")
            self.bbs = None
        
        logger.info(f"Issuer {issuer_id} initialized")
    
    def issue_credential(self,
                        document_type: DocumentType,
                        attributes: Dict[str, Any],
                        holder_id: str,
                        valid_from: Optional[datetime] = None,
                        valid_until: Optional[datetime] = None) -> DTCCredential:
        """
        Issue a credential with BBS signature over attribute messages
        
        Converts credential attributes to BBS message vector and signs with issuer's
        secret key. The resulting signature allows holders to generate ZK proofs
        for selective disclosure.
        """
        credential_id = f"{self.issuer_id}_{document_type.value}_{holder_id.split('@')[0]}_{int(datetime.now().timestamp())}"

        # Select appropriate schema for credential type
        schema_map = {
            DocumentType.PASSPORT: PASSPORT_SCHEMA,
            DocumentType.VISA: VISA_SCHEMA,
            DocumentType.VACCINATION: VACCINATION_SCHEMA
        }
        schema = schema_map.get(document_type, PASSPORT_SCHEMA)

        # Convert raw attributes to structured CredentialAttribute objects
        credential_attributes = {}
        for attr_def in schema.attributes:
            name = attr_def["name"]
            if name in attributes:
                attr_type = AttributeType(attr_def["type"])
                value = attributes[name]
                
                # Convert string dates to proper date objects for consistency
                if attr_type == AttributeType.DATE and isinstance(value, str):
                    try:
                        value = datetime.fromisoformat(value).date()
                    except:
                        value = datetime.strptime(value, "%Y-%m-%d").date()
                
                credential_attributes[name] = CredentialAttribute(
                    name=name,
                    value=value,
                    type=attr_type,
                    required=attr_def.get("required", False),
                    hidden=attr_def.get("hidden", False)
                )

        # Create DTC credential structure
        credential = DTCCredential(
            credential_id=credential_id,
            document_type=document_type,
            schema=schema,
            issuer_id=self.issuer_id,
            holder_id=holder_id,
            attributes=credential_attributes,
            issued_at=datetime.now(),
            expires_at=valid_until
        )
        
        # Convert credential to BBS message vector
        # Each attribute becomes a separate message for selective disclosure
        messages = credential.to_message_list()
        
        # Create signing context header
        header = f"{document_type.value}:{self.issuer_id}".encode()
        
        # Generate BBS signature over the message vector
        try:
            if self.bbs:
                signature = self.bbs.sign(self.secret_key, messages, header)
                credential.signature = signature
                credential.signature_bytes = signature.to_bytes()  # Standard 80-byte BBS signature
            else:
                # Fallback for testing without real BBS implementation
                mock_signature = BBSSignature(A=None, e=12345)
                credential.signature = mock_signature
                credential.signature_bytes = mock_signature.to_bytes()
        except Exception as e:
            logger.warning(f"Failed to sign credential: {e}, using mock signature")
            mock_signature = BBSSignature(A=None, e=12345)
            credential.signature = mock_signature
            credential.signature_bytes = mock_signature.to_bytes()
        
        logger.info(f"Issued {document_type.value} credential for {holder_id}")
        
        return credential
    
    def issue_passport(self, holder_name: str, document_number: str, nationality: str,
                      date_of_birth: str, place_of_birth: str, gender: str = None,
                      date_of_issue: str = None, date_of_expiry: str = None,
                      issuing_authority: str = None, holder_id: str = None,
                      photo_hash: str = None, biometric_hash: str = None) -> PassportCredential:
        """Issue a passport credential with BBS signature"""
        # Set reasonable defaults for optional fields
        if not holder_id:
            holder_id = holder_name.lower().replace(" ", "_") + "@passport.holder"
        if not date_of_issue:
            date_of_issue = datetime.now().strftime("%Y-%m-%d")
        if not date_of_expiry:
            date_of_expiry = datetime.now().replace(year=datetime.now().year + 10).strftime("%Y-%m-%d")
        if not issuing_authority:
            issuing_authority = f"{self.issuer_id} Passport Office"
        
        # Create passport credential with provided attributes
        passport = PassportCredential(
            issuer_id=self.issuer_id,
            holder_id=holder_id,
            document_number=document_number,
            holder_name=holder_name,
            nationality=nationality,
            date_of_birth=date_of_birth,
            place_of_birth=place_of_birth,
            gender=gender,
            date_of_issue=date_of_issue,
            date_of_expiry=date_of_expiry,
            issuing_authority=issuing_authority,
            photo_hash=photo_hash,
            biometric_hash=biometric_hash
        )
        
        # Sign the credential using BBS over the message vector
        messages = passport.to_message_list()
        header = f"{DocumentType.PASSPORT.value}:{self.issuer_id}".encode()
        
        try:
            if self.bbs:
                signature = self.bbs.sign(self.secret_key, messages, header)
                passport.signature = signature
                passport.signature_bytes = signature.to_bytes()
            else:
                mock_signature = BBSSignature(A=None, e=12345)
                passport.signature = mock_signature
                passport.signature_bytes = mock_signature.to_bytes()
        except Exception as e:
            logger.warning(f"Failed to sign passport: {e}")
            mock_signature = BBSSignature(A=None, e=12345)
            passport.signature = mock_signature
            passport.signature_bytes = mock_signature.to_bytes()
        
        logger.info(f"Issued passport credential for {holder_name}")
        return passport
    
    def issue_visa(self, visa_number: str, visa_type: str, passport_number: str,
                  holder_name: str, country_of_issue: str, valid_from: str,
                  valid_until: str, entries_allowed: str, duration_of_stay: int,
                  purpose: str = None, holder_id: str = None) -> VisaCredential:
        """Issue a visa credential with BBS signature"""
        if not holder_id:
            holder_id = holder_name.lower().replace(" ", "_") + "@visa.holder"
        
        visa = VisaCredential(
            issuer_id=self.issuer_id,
            holder_id=holder_id,
            visa_number=visa_number,
            visa_type=visa_type,
            passport_number=passport_number,
            holder_name=holder_name,
            country_of_issue=country_of_issue,
            valid_from=valid_from,
            valid_until=valid_until,
            entries_allowed=entries_allowed,
            duration_of_stay=duration_of_stay,
            purpose=purpose
        )
        
        # Sign with BBS
        messages = visa.to_message_list()
        header = f"{DocumentType.VISA.value}:{self.issuer_id}".encode()
        
        try:
            if self.bbs:
                signature = self.bbs.sign(self.secret_key, messages, header)
                visa.signature = signature
                visa.signature_bytes = signature.to_bytes()
            else:
                mock_signature = BBSSignature(A=None, e=12345)
                visa.signature = mock_signature
                visa.signature_bytes = mock_signature.to_bytes()
        except Exception as e:
            logger.warning(f"Failed to sign visa: {e}")
            mock_signature = BBSSignature(A=None, e=12345)
            visa.signature = mock_signature
            visa.signature_bytes = mock_signature.to_bytes()
        
        logger.info(f"Issued visa credential for {holder_name}")
        return visa
    
    def issue_vaccination(self, certificate_id: str, holder_name: str, date_of_birth: str,
                         vaccine_type: str, vaccine_name: str, manufacturer: str,
                         batch_number: str, vaccination_date: str, vaccination_center: str,
                         country_of_vaccination: str, dose_number: int, total_doses: int,
                         next_dose_date: str = None, holder_id: str = None) -> VaccinationCredential:
        """Issue a vaccination credential with BBS signature"""
        if not holder_id:
            holder_id = holder_name.lower().replace(" ", "_") + "@vaccination.holder"
        
        vaccination = VaccinationCredential(
            issuer_id=self.issuer_id,
            holder_id=holder_id,
            certificate_id=certificate_id,
            holder_name=holder_name,
            date_of_birth=date_of_birth,
            vaccine_type=vaccine_type,
            vaccine_name=vaccine_name,
            manufacturer=manufacturer,
            batch_number=batch_number,
            vaccination_date=vaccination_date,
            vaccination_center=vaccination_center,
            country_of_vaccination=country_of_vaccination,
            dose_number=dose_number,
            total_doses=total_doses,
            next_dose_date=next_dose_date
        )
        
        # Sign with BBS
        messages = vaccination.to_message_list()
        header = f"{DocumentType.VACCINATION.value}:{self.issuer_id}".encode()
        
        try:
            if self.bbs:
                signature = self.bbs.sign(self.secret_key, messages, header)
                vaccination.signature = signature
                vaccination.signature_bytes = signature.to_bytes()
            else:
                mock_signature = BBSSignature(A=None, e=12345)
                vaccination.signature = mock_signature
                vaccination.signature_bytes = mock_signature.to_bytes()
        except Exception as e:
            logger.warning(f"Failed to sign vaccination certificate: {e}")
            mock_signature = BBSSignature(A=None, e=12345)
            vaccination.signature = mock_signature
            vaccination.signature_bytes = mock_signature.to_bytes()
        
        logger.info(f"Issued vaccination certificate for {holder_name}")
        return vaccination
    
    def get_public_key_bytes(self) -> bytes:
        """Get issuer's BBS public key in bytes format (96 bytes for G2 point)"""
        try:
            return self.public_key.to_bytes()
        except:
            return b'mock_pubkey_96_bytes' + b'\x00' * 84
    
    def get_public_key_base58(self) -> str:
        """Get issuer's BBS public key in base58 format for sharing"""
        try:
            return self.public_key.to_base58()
        except:
            return "mock_base58_pubkey"
    
    def get_issuer_info(self) -> Dict[str, Any]:
        """Get issuer information including BBS public key"""
        return {
            "issuer_id": self.issuer_id,
            "max_messages": self.max_messages,
            "public_key_base58": self.get_public_key_base58(),
            "supported_documents": [doc.value for doc in DocumentType]
        }


def create_test_issuer(issuer_id: str = "test_issuer") -> DTCIssuer:
    """Create a DTCIssuer for testing purposes"""
    return DTCIssuer(issuer_id)